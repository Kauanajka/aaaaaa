<?php

define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://teste1.atacadaodoinsta.com');
define('STYLESHEETS_URL', '//teste1.atacadaodoinsta.com');

error_reporting(1);
date_default_timezone_set('Asia/Kolkata');


return [
  'db' => [
    'name'    =>  'zeyinsta_teste13',
    'host'    =>  'localhost',
    'user'    =>  'zeyinsta_teste13',
    'pass'    =>  'HsPKHZGoV~uw',
    'charset' =>  'utf8mb4' 
  ]
];
