<?php

if(isset($_REQUEST['refill'])){
    $id = $_REQUEST['id'];
    
    $orders = $conn->prepare("SELECT * FROM orders WHERE order_id=:id ");
    $orders-> execute(array("id"=>$id));
    $orders = $orders->fetchAll(PDO::FETCH_OBJ);
    
    if(count($orders)>0){
        $order = $orders[0];
        
    
         
        $api_service = $conn->prepare("SELECT * FROM service_api WHERE id=:id ");
        $api_service-> execute(array("id"=>$order->order_api));
        $api_service = $api_service->fetchAll(PDO::FETCH_OBJ);
         
        if(count($api_service)>0){
            
            $api_service = $api_service[0];
            
            if($order->order_refill == '0'){
                // add refill
                
                $data['key']    = $api_service->api_key;
                $data['action'] = 'refill';
                $data['order']  = $order->api_orderid;
                
            
                $ch = curl_init($api_service->api_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                if (is_array($data)) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data) );
                }
                curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
                $result = curl_exec($ch);
                if (curl_errno($ch) != 0 && empty($result)) {
                    $result = false;
                }
                curl_close($ch);
                
        
                if($result){
                    
                    $result = json_decode($result);
                    
                    if(isset($result->refill)){
                         $orders = $conn->prepare("UPDATE orders SET order_refill='{$result->refill}' WHERE order_id=:id ");
                         $orders-> execute(array("id"=>$id));
                         
                         echo json_encode(array('erro' => false, 'msg' => 'Demos inicio a sua reposição.'));
                         
                    }else{
                        
                        if($result->error == "Refill not allowed"){
                            echo json_encode(array('erro' => true, 'msg' => 'Pacote escolhido, não permite reposição'));

                        }else{
                            echo json_encode(array('erro' => true, 'msg' => $result->error));

                        }
                        
                    }
                    
                }else{
                    echo json_encode(array('erro' => true, 'msg' => 'api error L:60'));
                }
                            
                
            }else{
                // get status refill
                
                $data['key']     = $api_service->api_key;
                $data['action']  = 'refill_status';
                $data['refill']  = $order->order_refill;
                
            
                $ch = curl_init($api_service->api_url);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
                if (is_array($data)) {
                    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data) );
                }
                curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
                $result = curl_exec($ch);
                if (curl_errno($ch) != 0 && empty($result)) {
                    $result = false;
                }
                curl_close($ch);
                
                if($result){
                    
                    $result = json_decode($result);
                    
                     if(isset($result->status)){
                         echo json_encode(array('erro' => false, 'msg' => 'Status da sua reposição é '.$result->status));
                     }else{
                            echo json_encode(array('erro' => true, 'msg' => $result->error));
                        }
                    
                    
                }else{
                    echo json_encode(array('erro' => true, 'msg' => 'api error L:99'));
                }
                
            }
            
            
            
        }else{
            echo json_encode(array('erro' => true, 'msg' => 'api service not found'));
        }
    
    }else{
        echo json_encode(array('erro' => true, 'msg' => 'order not found'));
    }
    
   
    die;
}

$title .= $languageArray["orders.title"];

if( $_SESSION["msmbilisim_userlogin"] != 1  || $user["client_type"] == 1  ){
  Header("Location:".site_url('logout'));
}

$status_list  = ["all","pending","inprogress","completed","partial","processing","canceled"];
$search_statu = route(1); if( !route(1) ):  $route[1] = "all";  endif;

  if( !in_array($search_statu,$status_list) ):
    $route[1]         = "all";
  endif;

  if( route(2) ):
    $page         = route(2);
  else:
    $page         = 1;
  endif;
    if( route(1) != "all" ): $search  = "&& order_status='".route(1)."'"; else: $search = ""; endif;
    if( !empty(urldecode($_GET["search"])) ): $search.= " && ( order_url LIKE '%".urldecode($_GET["search"])."%' || order_id LIKE '%".urldecode($_GET["search"])."%' ) "; endif;
    if( !empty($_GET["subscription"]) ): $search.= " && ( subscriptions_id LIKE '%".$_GET["subscription"]."%'  ) "; endif;
    if( !empty($_GET["dripfeed"]) ): $search.= " && ( dripfeed_id LIKE '%".$_GET["dripfeed"]."%'  ) "; endif;
    $c_id       = $user["client_id"];
    $to         = 25;
    $count      = $conn->query("SELECT * FROM orders WHERE client_id='$c_id' && dripfeed='1' && subscriptions_type='1' $search ")->rowCount();
    $pageCount  = ceil($count/$to);
      if( $page > $pageCount ): $page = 1; endif;
    $where      = ($page*$to)-$to;
    $paginationArr = ["count"=>$pageCount,"current"=>$page,"next"=>$page+1,"previous"=>$page-1];

    $orders = $conn->prepare("SELECT * FROM orders INNER JOIN services WHERE services.service_id = orders.service_id && orders.dripfeed=:dripfeed && orders.subscriptions_type=:subs && orders.client_id=:c_id $search ORDER BY orders.order_id DESC LIMIT $where,$to ");
    $orders-> execute(array("c_id"=>$user["client_id"],"dripfeed"=>1,"subs"=>1 ));
    $orders = $orders->fetchAll(PDO::FETCH_ASSOC);

  $ordersList = [];

    foreach ($orders as $order) {
      $o["id"]    = $order["order_id"];
      $o["date"]  = date("Y-m-d H:i:s", (strtotime($order["order_create"])+$user["timezone"]));
      $o["link"]    = $order["order_url"];
      $o["charge"]  = $order["order_charge"];
      $o["start_count"]  = $order["order_start"];
      $o["quantity"]  = $order["order_quantity"];
      $o["service"]  = $order["service_name"];
      $o["refill"] = $order["refill"];
      $o["status"]  = $languageArray["orders.status.".$order["order_status"]];
      if( $order["order_status"] == "completed" && substr($order["order_remains"], 0,1) == "-" ):
        $o["remains"]  = "+".substr($order["order_remains"], 1);
      else:
        $o["remains"]  = $order["order_remains"];
      endif;
      array_push($ordersList,$o);
    }
