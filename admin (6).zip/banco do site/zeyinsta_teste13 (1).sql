-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 17-Jan-2023 às 18:30
-- Versão do servidor: 10.5.17-MariaDB-cll-lve
-- versão do PHP: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `zeyinsta_teste13`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(225) NOT NULL,
  `bank_sube` varchar(225) NOT NULL,
  `bank_hesap` varchar(225) NOT NULL,
  `bank_iban` text NOT NULL,
  `bank_alici` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` text COLLATE utf8mb4_bin NOT NULL,
  `category_line` double NOT NULL,
  `category_type` enum('1','2') CHARACTER SET utf8 NOT NULL DEFAULT '2',
  `category_secret` enum('1','2') COLLATE utf8mb4_bin NOT NULL DEFAULT '2',
  `category_icon` text COLLATE utf8mb4_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- Estrutura da tabela `clients`
--

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `email` varchar(225) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` text NOT NULL,
  `telephone` varchar(225) DEFAULT NULL,
  `balance` double NOT NULL DEFAULT 0,
  `balance_type` enum('1','2') NOT NULL DEFAULT '2',
  `debit_limit` double DEFAULT NULL,
  `spent` double NOT NULL DEFAULT 0,
  `register_date` datetime NOT NULL,
  `login_date` datetime DEFAULT NULL,
  `login_ip` varchar(225) DEFAULT NULL,
  `apikey` text NOT NULL,
  `tel_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `email_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `client_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF',
  `access` text DEFAULT NULL,
  `lang` varchar(255) NOT NULL DEFAULT 'tr',
  `timezone` double NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `clients`
--

INSERT INTO `clients` (`client_id`, `name`, `email`, `username`, `password`, `telephone`, `balance`, `balance_type`, `debit_limit`, `spent`, `register_date`, `login_date`, `login_ip`, `apikey`, `tel_type`, `email_type`, `client_type`, `access`, `lang`, `timezone`) VALUES
(217, 'PAGAMENTO PIX MANUAL', 'supo@gmail.com', 'felix06', 'e4f39ea94dff9fd4b7471f2b49da51d6', '85082785', 0.965, '2', NULL, 0.035, '2023-01-17 22:05:08', '2023-01-17 22:58:41', '45.166.204.188', '434b9b7d75ae6c5ec47177c064b39b39', '1', '1', '2', '{\"admin_access\":\"1\",\"users\":\"1\",\"orders\":\"1\",\"subscriptions\":\"1\",\"dripfeed\":\"1\",\"services\":\"1\",\"payments\":\"1\",\"tickets\":\"1\",\"reports\":\"1\",\"general_settings\":\"1\",\"pages\":\"1\",\"payments_settings\":\"1\",\"bank_accounts\":\"1\",\"payments_bonus\":\"1\",\"alert_settings\":\"1\",\"providers\":\"1\",\"themes\":\"1\",\"admins\":\"1\",\"language\":\"1\",\"meta\":\"1\",\"proxy\":\"1\",\"kuponlar\":\"1\"}', 'en', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `clients_category`
--

CREATE TABLE `clients_category` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `clients_price`
--

CREATE TABLE `clients_price` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_price` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `clients_service`
--

CREATE TABLE `clients_service` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `client_report`
--

CREATE TABLE `client_report` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `action` text NOT NULL,
  `report_ip` varchar(225) NOT NULL,
  `report_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `client_report`
--

INSERT INTO `client_report` (`id`, `client_id`, `action`, `report_ip`, `report_date`) VALUES
(4, 162, 'Yönetici girişi yapıldı.', '157.44.218.6', '2021-01-01 13:36:07'),
(5, 162, 'Yönetici girişi yapıldı.', '157.44.218.6', '2021-01-01 13:41:19'),
(9, 162, 'Üye girişi yapıldı.', '58.145.184.226', '2021-01-01 16:35:18'),
(16, 162, 'Üye girişi yapıldı.', '8.38.148.165', '2021-01-02 23:42:38'),
(17, 162, 'Yönetici girişi yapıldı.', '103.250.165.57', '2021-01-02 23:43:32'),
(19, 162, 'Yönetici girişi yapıldı.', '106.210.210.171', '2021-01-03 00:02:30'),
(20, 162, 'Yönetici girişi yapıldı.', '103.250.165.57', '2021-01-03 00:13:48'),
(21, 162, 'Yönetici girişi yapıldı.', '103.250.165.57', '2021-01-03 00:21:47'),
(22, 162, 'Üye girişi yapıldı.', '157.46.215.105', '2021-01-03 18:28:30'),
(23, 162, 'Üye girişi yapıldı.', '157.42.251.215', '2021-01-03 18:37:03'),
(24, 163, 'Kullanıcı kaydı yapıldı.', '223.188.112.58', '2021-01-03 19:03:57'),
(25, 163, 'Üye girişi yapıldı.', '223.188.112.58', '2021-01-03 19:04:10'),
(26, 164, 'Kullanıcı kaydı yapıldı.', '27.97.189.110', '2021-01-03 22:54:41'),
(27, 164, 'Üye girişi yapıldı.', '27.97.189.110', '2021-01-03 22:54:57'),
(28, 162, 'Yönetici girişi yapıldı.', '157.44.209.205', '2021-01-04 13:34:50'),
(29, 165, 'Kullanıcı kaydı yapıldı.', '124.253.166.217', '2021-01-04 18:36:15'),
(30, 165, 'Üye girişi yapıldı.', '124.253.166.217', '2021-01-04 18:36:22'),
(31, 162, 'Yönetici girişi yapıldı.', '124.253.166.217', '2021-01-04 18:37:49'),
(32, 166, 'Kullanıcı kaydı yapıldı.', '157.38.78.52', '2021-01-04 18:44:24'),
(33, 166, 'Üye girişi yapıldı.', '157.38.78.52', '2021-01-04 18:44:36'),
(34, 167, 'Kullanıcı kaydı yapıldı.', '103.66.214.153', '2021-01-04 19:46:28'),
(35, 162, 'Üye girişi yapıldı.', '103.66.214.153', '2021-01-04 19:47:30'),
(36, 168, 'Kullanıcı kaydı yapıldı.', '119.160.65.195', '2021-01-05 10:06:17'),
(37, 168, 'Üye girişi yapıldı.', '119.160.65.195', '2021-01-05 10:06:29'),
(38, 162, 'Yönetici girişi yapıldı.', '119.160.65.195', '2021-01-05 10:08:03'),
(39, 162, 'Yönetici girişi yapıldı.', '103.127.20.158', '2021-01-05 21:26:51'),
(40, 168, 'Üye girişi yapıldı.', '182.186.200.119', '2021-01-06 12:04:24'),
(41, 162, 'Yönetici girişi yapıldı.', '182.186.184.153', '2021-01-07 22:39:21'),
(42, 162, 'Üye girişi yapıldı.', '223.184.201.195', '2021-01-08 18:58:05'),
(43, 162, 'Üye girişi yapıldı.', '223.184.201.195', '2021-01-08 19:04:44'),
(44, 162, 'Üye girişi yapıldı.', '157.42.25.191', '2021-01-09 11:51:48'),
(45, 162, 'Yönetici girişi yapıldı.', '157.42.25.191', '2021-01-09 11:55:26'),
(46, 162, 'Üye girişi yapıldı.', '202.142.119.171', '2021-01-09 19:14:34'),
(47, 162, 'Üye girişi yapıldı.', '111.119.187.51', '2021-01-09 22:15:22'),
(50, 162, 'Üye girişi yapıldı.', '223.189.57.97', '2021-01-12 12:08:25'),
(51, 166, 'Üye girişi yapıldı.', '157.38.13.95', '2021-01-15 00:16:13'),
(52, 162, 'Yönetici girişi yapıldı.', '49.15.82.148', '2021-01-15 16:19:46'),
(54, 162, 'Yönetici girişi yapıldı.', '157.46.137.139', '2021-01-16 02:37:17'),
(59, 169, 'Kullanıcı kaydı yapıldı.', '212.156.147.70', '2021-01-26 17:59:51'),
(60, 169, 'Üye girişi yapıldı.', '212.156.147.70', '2021-01-26 18:00:05'),
(61, 170, 'Üye girişi yapıldı.', '137.97.94.239', '2021-01-26 18:00:49'),
(62, 170, 'Yönetici girişi yapıldı.', '212.156.147.70', '2021-01-26 18:02:33'),
(63, 170, 'Yönetici girişi yapıldı.', '212.156.147.70', '2021-01-26 18:02:34'),
(64, 170, 'Üye girişi yapıldı.', '88.236.65.0', '2021-01-26 18:04:27'),
(65, 170, 'Üye girişi yapıldı.', '188.253.231.64', '2021-01-26 18:10:23'),
(70, 170, 'Üye girişi yapıldı.', '157.34.76.180', '2021-01-27 13:28:52'),
(72, 170, 'Yönetici girişi yapıldı.', '157.34.76.180', '2021-01-27 13:30:39'),
(73, 170, 'Yönetici girişi yapıldı.', '137.97.64.174', '2021-01-27 16:27:13'),
(95, 99, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 00:00:52'),
(96, 99, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-12 00:03:03'),
(97, 171, 'Kullanıcı kaydı yapıldı.', '187.19.159.172', '2021-08-12 00:07:51'),
(98, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 00:07:59'),
(99, 99, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-12 00:09:12'),
(100, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-12 00:14:37'),
(101, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-12 04:05:59'),
(102, 172, 'Kullanıcı kaydı yapıldı.', '189.40.101.182', '2021-08-12 07:13:34'),
(103, 172, 'Üye girişi yapıldı.', '189.40.101.182', '2021-08-12 07:13:41'),
(104, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 07:23:00'),
(105, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 07:47:28'),
(106, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-12 08:43:10'),
(107, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 08:44:52'),
(108, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 08:46:13'),
(109, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 08:47:13'),
(110, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 08:48:54'),
(111, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 08:51:21'),
(112, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 08:51:53'),
(113, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 08:52:44'),
(114, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 08:53:19'),
(115, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 08:54:09'),
(116, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-12 10:12:54'),
(117, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 10:14:08'),
(118, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 11:58:56'),
(119, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-12 12:01:11'),
(120, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-13 05:44:26'),
(121, 171, '0 TL tutarında yeni sipariş geçildi #.', '187.19.159.172', '2021-08-13 05:44:34'),
(122, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-13 06:58:03'),
(123, 171, '0.025 TL tutarında yeni sipariş geçildi #1.', '187.19.159.172', '2021-08-13 07:16:55'),
(124, 171, '0.065 TL tutarında yeni sipariş geçildi #2.', '187.19.159.172', '2021-08-13 07:36:01'),
(125, 171, '#1 numaralı sipariş iptal edildi ve 0.025 TL ücret iade edildi Eski bakiye:5.97 / Yeni bakiye:5.995', '127.0.0.1', '2021-08-13 07:40:11'),
(126, 171, '0.075 TL tutarında yeni sipariş geçildi #3.', '187.19.159.172', '2021-08-13 07:46:59'),
(127, 171, '#2 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-13 07:48:08'),
(128, 171, '#3 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-13 07:53:07'),
(129, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-13 08:05:48'),
(130, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-13 08:37:16'),
(131, 173, 'Kullanıcı kaydı yapıldı.', '179.127.71.83', '2021-08-13 08:45:33'),
(132, 173, 'Üye girişi yapıldı.', '179.127.71.83', '2021-08-13 08:45:50'),
(133, 174, 'Kullanıcı kaydı yapıldı.', '131.196.79.42', '2021-08-13 08:50:25'),
(134, 174, 'Üye girişi yapıldı.', '131.196.79.42', '2021-08-13 08:50:36'),
(135, 175, 'Kullanıcı kaydı yapıldı.', '179.240.24.113', '2021-08-13 09:08:22'),
(136, 175, 'Üye girişi yapıldı.', '179.240.24.113', '2021-08-13 09:08:30'),
(137, 171, '0.5 TL tutarında yeni sipariş geçildi #4.', '187.19.159.172', '2021-08-13 11:04:37'),
(138, 176, 'Kullanıcı kaydı yapıldı.', '45.70.190.30', '2021-08-13 11:55:45'),
(139, 176, 'Üye girişi yapıldı.', '45.70.190.30', '2021-08-13 11:56:01'),
(140, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-13 12:03:16'),
(141, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-13 12:05:28'),
(142, 171, '#4 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-13 12:48:09'),
(143, 171, '0.04 TL tutarında yeni sipariş geçildi #5.', '187.19.159.172', '2021-08-13 12:57:54'),
(144, 171, '#5 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-13 13:09:09'),
(145, 171, '0.39 TL tutarında yeni sipariş geçildi #6.', '187.19.159.172', '2021-08-13 13:13:13'),
(146, 171, '#6 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-13 13:18:10'),
(147, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-13 14:21:15'),
(148, 177, 'Kullanıcı kaydı yapıldı.', '177.188.63.26', '2021-08-13 16:27:43'),
(149, 177, 'Üye girişi yapıldı.', '177.188.63.26', '2021-08-13 16:27:55'),
(150, 171, 'Üye girişi yapıldı.', '177.79.108.178', '2021-08-13 16:57:37'),
(151, 178, 'Kullanıcı kaydı yapıldı.', '179.127.16.154', '2021-08-13 19:48:47'),
(152, 178, 'Üye girişi yapıldı.', '179.127.16.154', '2021-08-13 19:48:59'),
(153, 179, 'Kullanıcı kaydı yapıldı.', '190.83.108.65', '2021-08-13 20:30:53'),
(154, 179, 'Üye girişi yapıldı.', '190.83.108.65', '2021-08-13 20:31:06'),
(155, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-14 17:02:26'),
(156, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-15 11:04:34'),
(157, 180, 'Kullanıcı kaydı yapıldı.', '45.190.254.100', '2021-08-15 22:24:23'),
(158, 180, 'Üye girişi yapıldı.', '45.190.254.100', '2021-08-15 22:24:40'),
(159, 181, 'Kullanıcı kaydı yapıldı.', '191.39.71.117', '2021-08-16 04:15:30'),
(160, 181, 'Üye girişi yapıldı.', '191.39.71.117', '2021-08-16 04:15:40'),
(161, 180, 'API Key değiştirildi', '45.190.254.61', '2021-08-16 05:16:54'),
(162, 180, 'API Key değiştirildi', '45.190.254.61', '2021-08-16 05:17:13'),
(163, 180, '0 TL tutarında yeni sipariş geçildi #.', '45.190.254.244', '2021-08-17 00:10:21'),
(164, 180, '0 TL tutarında yeni sipariş geçildi #.', '45.190.254.244', '2021-08-17 00:10:31'),
(165, 182, 'Kullanıcı kaydı yapıldı.', '45.7.26.164', '2021-08-18 01:00:34'),
(166, 182, 'Üye girişi yapıldı.', '45.7.26.164', '2021-08-18 01:00:39'),
(167, 174, 'Üye girişi yapıldı.', '131.196.79.42', '2021-08-18 01:45:28'),
(168, 174, '0 TL tutarında yeni sipariş geçildi #.', '131.196.79.42', '2021-08-18 08:56:49'),
(169, 183, 'Kullanıcı kaydı yapıldı.', '191.96.9.153', '2021-08-18 21:19:51'),
(170, 183, 'Üye girişi yapıldı.', '191.96.9.153', '2021-08-18 21:20:00'),
(171, 171, 'Yönetici girişi yapıldı.', '187.19.159.124', '2021-08-19 19:31:41'),
(172, 171, 'Üye girişi yapıldı.', '45.165.24.38', '2021-08-20 02:46:22'),
(173, 171, 'Üye girişi yapıldı.', '187.19.159.124', '2021-08-20 14:06:28'),
(174, 171, '0.027 TL tutarında yeni sipariş geçildi #7.', '187.19.159.124', '2021-08-20 14:09:57'),
(175, 171, '0.027 TL tutarında yeni sipariş geçildi #8.', '187.19.159.124', '2021-08-20 14:43:32'),
(176, 171, '#8 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-20 14:47:08'),
(177, 174, 'Üye girişi yapıldı.', '131.196.79.42', '2021-08-20 21:27:44'),
(178, 174, 'Üye girişi yapıldı.', '131.196.79.42', '2021-08-20 22:55:48'),
(179, 180, 'Üye girişi yapıldı.', '45.190.254.28', '2021-08-21 01:16:52'),
(180, 171, 'Yönetici girişi yapıldı.', '187.19.159.148', '2021-08-21 14:23:48'),
(181, 171, '0 TL tutarında yeni sipariş geçildi #.', '187.19.159.148', '2021-08-21 16:44:33'),
(182, 171, '0 TL tutarında yeni sipariş geçildi #.', '187.19.159.148', '2021-08-21 16:44:39'),
(183, 171, '0 TL tutarında yeni sipariş geçildi #.', '187.19.159.148', '2021-08-21 16:44:49'),
(184, 171, 'Üye girişi yapıldı.', '187.19.159.148', '2021-08-21 16:45:24'),
(185, 184, 'Kullanıcı kaydı yapıldı.', '187.7.230.2', '2021-08-21 20:47:53'),
(186, 184, 'Üye girişi yapıldı.', '187.7.230.2', '2021-08-21 20:48:13'),
(187, 172, 'Üye girişi yapıldı.', '187.19.159.141', '2021-08-21 20:55:59'),
(188, 184, '13.5 TL tutarında yeni sipariş geçildi #9.', '187.7.230.2', '2021-08-21 21:02:38'),
(189, 171, 'Yönetici girişi yapıldı.', '187.19.159.148', '2021-08-21 21:16:02'),
(190, 184, '2.7 TL tutarında yeni sipariş geçildi #10.', '45.6.111.240', '2021-08-21 21:44:23'),
(191, 184, '2.7 TL tutarında yeni sipariş geçildi #11.', '45.6.111.242', '2021-08-21 22:45:54'),
(192, 184, '0.27 TL tutarında yeni sipariş geçildi #12.', '45.6.111.242', '2021-08-21 22:50:13'),
(193, 184, '#12 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-21 22:59:08'),
(194, 184, '10.8 TL tutarında yeni sipariş geçildi #13.', '45.6.111.242', '2021-08-21 23:07:12'),
(195, 184, '2.7 TL tutarında yeni sipariş geçildi #14.', '45.6.111.242', '2021-08-21 23:36:15'),
(196, 184, '0.27 TL tutarında yeni sipariş geçildi #15.', '45.6.111.242', '2021-08-21 23:52:05'),
(197, 184, '#11 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 00:03:07'),
(198, 184, '#15 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 00:03:08'),
(199, 184, '0.18 TL tutarında yeni sipariş geçildi #16.', '45.6.111.242', '2021-08-22 00:20:06'),
(200, 171, 'Yönetici girişi yapıldı.', '187.19.159.148', '2021-08-22 01:13:24'),
(201, 184, '#14 numaralı sipariş iptal edildi ve 2.7 TL ücret iade edildi Eski bakiye:3.28 / Yeni bakiye:5.98', '127.0.0.1', '2021-08-22 01:46:07'),
(202, 184, '2.7 TL tutarında yeni sipariş geçildi #17.', '45.6.111.242', '2021-08-22 02:00:19'),
(203, 184, '0.18 TL tutarında yeni sipariş geçildi #18.', '45.6.111.242', '2021-08-22 02:54:16'),
(204, 184, '#18 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 03:17:10'),
(205, 184, '#17 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 03:23:08'),
(206, 184, '13.5 TL tutarında yeni sipariş geçildi #19.', '45.6.111.242', '2021-08-22 03:27:28'),
(207, 185, 'Kullanıcı kaydı yapıldı.', '45.224.0.20', '2021-08-22 16:37:41'),
(208, 185, 'Üye girişi yapıldı.', '45.224.0.20', '2021-08-22 16:37:58'),
(209, 184, '#19 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 17:26:08'),
(210, 186, 'Kullanıcı kaydı yapıldı.', '187.15.20.131', '2021-08-22 18:18:42'),
(211, 186, 'Üye girişi yapıldı.', '187.15.20.131', '2021-08-22 18:19:30'),
(212, 187, 'Kullanıcı kaydı yapıldı.', '45.224.0.20', '2021-08-22 19:10:13'),
(213, 187, 'Üye girişi yapıldı.', '45.224.0.20', '2021-08-22 19:10:26'),
(214, 184, '5.25 TL tutarında yeni sipariş geçildi #20.', '45.6.111.242', '2021-08-22 20:00:16'),
(215, 174, '6 TL tutarında yeni sipariş geçildi #21.', '131.196.79.42', '2021-08-22 21:40:32'),
(216, 174, 'Yeni destek talebi oluşturuldu #6', '131.196.79.42', '2021-08-22 21:48:05'),
(217, 174, 'Yeni destek talebi oluşturuldu #7', '131.196.79.42', '2021-08-22 22:52:56'),
(218, 184, '13.5 TL tutarında yeni sipariş geçildi #22.', '45.6.111.242', '2021-08-22 22:58:16'),
(219, 174, '0.0945 TL tutarında yeni sipariş geçildi #23.', '131.196.79.42', '2021-08-22 23:00:57'),
(220, 174, '0.0945 TL tutarında yeni sipariş geçildi #24.', '131.196.79.42', '2021-08-22 23:01:31'),
(221, 174, '0.0945 TL tutarında yeni sipariş geçildi #25.', '131.196.79.42', '2021-08-22 23:01:42'),
(222, 174, '0.0945 TL tutarında yeni sipariş geçildi #26.', '131.196.79.42', '2021-08-22 23:01:53'),
(223, 174, '0.0945 TL tutarında yeni sipariş geçildi #27.', '131.196.79.42', '2021-08-22 23:02:06'),
(224, 174, '0.0945 TL tutarında yeni sipariş geçildi #28.', '131.196.79.42', '2021-08-22 23:02:19'),
(225, 174, '0.0945 TL tutarında yeni sipariş geçildi #29.', '131.196.79.42', '2021-08-22 23:02:30'),
(226, 174, '0.0945 TL tutarında yeni sipariş geçildi #30.', '131.196.79.42', '2021-08-22 23:02:55'),
(227, 174, '0.0945 TL tutarında yeni sipariş geçildi #31.', '131.196.79.42', '2021-08-22 23:03:09'),
(228, 174, '#23 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 23:05:08'),
(229, 174, '#24 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 23:07:08'),
(230, 174, '#25 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 23:07:09'),
(231, 174, '#26 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 23:07:09'),
(232, 174, '#27 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 23:07:09'),
(233, 174, '#28 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-22 23:07:10'),
(234, 188, 'Kullanıcı kaydı yapıldı.', '177.37.227.8', '2021-08-22 23:08:40'),
(235, 188, 'Üye girişi yapıldı.', '177.37.227.8', '2021-08-22 23:08:53'),
(236, 184, '0.27 TL tutarında yeni sipariş geçildi #32.', '45.6.111.242', '2021-08-23 00:23:25'),
(237, 174, '0.0945 TL tutarında yeni sipariş geçildi #33.', '131.196.79.42', '2021-08-23 00:24:24'),
(238, 174, 'Yeni destek talebi oluşturuldu #8', '131.196.79.42', '2021-08-23 01:33:48'),
(239, 184, '0.27 TL tutarında yeni sipariş geçildi #34.', '45.6.108.230', '2021-08-23 03:18:33'),
(240, 184, '0.9 TL tutarında yeni sipariş geçildi #35.', '45.6.108.230', '2021-08-23 05:08:21'),
(241, 184, 'Üye girişi yapıldı.', '45.6.111.242', '2021-08-23 08:36:10'),
(242, 184, '0.5775 TL tutarında yeni sipariş geçildi #36.', '45.6.111.242', '2021-08-23 09:22:49'),
(243, 189, 'Kullanıcı kaydı yapıldı.', '179.118.210.196', '2021-08-23 10:12:30'),
(244, 189, 'Üye girişi yapıldı.', '179.118.210.196', '2021-08-23 10:12:46'),
(245, 171, 'Üye girişi yapıldı.', '187.19.159.28', '2021-08-23 18:16:17'),
(246, 190, 'Kullanıcı kaydı yapıldı.', '191.243.24.223', '2021-08-24 01:29:06'),
(247, 190, 'Üye girişi yapıldı.', '191.243.24.223', '2021-08-24 01:29:15'),
(248, 191, 'Kullanıcı kaydı yapıldı.', '189.18.143.212', '2021-08-24 03:30:05'),
(249, 191, 'Üye girişi yapıldı.', '189.18.143.212', '2021-08-24 03:30:55'),
(250, 192, 'Kullanıcı kaydı yapıldı.', '138.185.238.161', '2021-08-24 04:18:04'),
(251, 192, 'Üye girişi yapıldı.', '138.185.238.161', '2021-08-24 04:18:09'),
(252, 184, '5.775 TL tutarında yeni sipariş geçildi #37.', '45.6.111.242', '2021-08-24 06:49:37'),
(253, 171, 'Yönetici girişi yapıldı.', '187.19.159.28', '2021-08-24 09:11:07'),
(254, 193, 'Kullanıcı kaydı yapıldı.', '201.49.205.223', '2021-08-24 10:13:11'),
(255, 193, 'Üye girişi yapıldı.', '201.49.205.223', '2021-08-24 10:13:50'),
(256, 171, 'Yönetici girişi yapıldı.', '187.19.159.28', '2021-08-24 19:50:31'),
(257, 171, 'Yönetici girişi yapıldı.', '187.19.159.28', '2021-08-24 19:54:25'),
(258, 171, 'Yönetici girişi yapıldı.', '187.19.159.28', '2021-08-24 19:54:41'),
(259, 184, '8.8 TL tutarında yeni sipariş geçildi #38.', '187.7.230.2', '2021-08-24 20:11:03'),
(260, 184, '#38 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-24 21:09:09'),
(261, 184, '8.8 TL tutarında yeni sipariş geçildi #39.', '187.7.230.2', '2021-08-24 21:36:42'),
(262, 171, 'Yönetici girişi yapıldı.', '187.19.159.28', '2021-08-24 22:35:59'),
(263, 184, '#39 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-24 22:43:09'),
(264, 171, '0 TL tutarında yeni sipariş geçildi #.', '187.19.159.28', '2021-08-24 23:08:19'),
(265, 171, '0 TL tutarında yeni sipariş geçildi #.', '187.19.159.28', '2021-08-24 23:08:23'),
(266, 171, 'Üye girişi yapıldı.', '187.19.159.28', '2021-08-24 23:08:28'),
(267, 184, '0 TL tutarında yeni sipariş geçildi #.', '45.6.111.242', '2021-08-25 06:05:06'),
(268, 184, 'Üye girişi yapıldı.', '45.6.111.242', '2021-08-25 06:05:38'),
(269, 171, 'Üye girişi yapıldı.', '187.19.159.28', '2021-08-25 21:15:00'),
(270, 184, '4.6288 TL tutarında yeni sipariş geçildi #40.', '187.7.230.2', '2021-08-25 21:46:35'),
(271, 172, 'Üye girişi yapıldı.', '177.12.221.191', '2021-08-25 21:52:23'),
(272, 193, 'Üye girişi yapıldı.', '177.79.16.71', '2021-08-27 01:49:32'),
(273, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-28 07:19:15'),
(274, 174, 'Üye girişi yapıldı.', '131.196.79.42', '2021-08-28 07:56:02'),
(275, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-29 00:47:11'),
(276, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-29 00:48:18'),
(277, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-29 00:48:32'),
(278, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-29 00:49:48'),
(279, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-29 00:50:50'),
(280, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-29 00:51:17'),
(281, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-29 00:53:42'),
(282, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-29 01:27:13'),
(283, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-29 01:50:50'),
(284, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-29 02:30:28'),
(285, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-29 02:31:28'),
(286, 194, 'Kullanıcı kaydı yapıldı.', '45.190.252.162', '2021-08-29 02:37:46'),
(287, 194, 'Üye girişi yapıldı.', '45.190.252.162', '2021-08-29 02:37:53'),
(288, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-29 02:46:59'),
(289, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-29 02:48:45'),
(290, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-29 02:50:04'),
(291, 171, '0.48 TL tutarında yeni sipariş geçildi #41.', '187.19.159.172', '2021-08-29 02:57:56'),
(292, 171, '#41 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-29 03:06:10'),
(293, 171, '0.675 TL tutarında yeni sipariş geçildi #42.', '187.19.159.172', '2021-08-29 03:14:56'),
(294, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-29 03:22:44'),
(295, 171, '#42 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-29 03:30:05'),
(296, 195, 'Kullanıcı kaydı yapıldı.', '201.5.107.73', '2021-08-29 19:41:43'),
(297, 195, 'Üye girişi yapıldı.', '201.5.107.73', '2021-08-29 19:41:55'),
(298, 196, 'Kullanıcı kaydı yapıldı.', '132.255.107.215', '2021-08-29 19:43:32'),
(299, 196, 'Üye girişi yapıldı.', '132.255.107.215', '2021-08-29 19:43:42'),
(300, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-29 20:01:54'),
(301, 197, 'Kullanıcı kaydı yapıldı.', '189.121.201.175', '2021-08-29 22:04:18'),
(302, 198, 'Kullanıcı kaydı yapıldı.', '189.121.201.175', '2021-08-29 22:06:40'),
(303, 198, 'Üye girişi yapıldı.', '189.121.201.175', '2021-08-29 22:06:56'),
(304, 199, 'Kullanıcı kaydı yapıldı.', '191.189.8.176', '2021-08-29 23:36:00'),
(305, 199, 'Üye girişi yapıldı.', '191.189.8.176', '2021-08-29 23:36:08'),
(306, 199, 'Üye girişi yapıldı.', '191.189.8.176', '2021-08-29 23:38:38'),
(307, 172, 'Üye girişi yapıldı.', '45.190.252.162', '2021-08-30 01:18:11'),
(308, 200, 'Kullanıcı kaydı yapıldı.', '177.130.73.17', '2021-08-30 03:33:24'),
(309, 200, 'Üye girişi yapıldı.', '177.130.73.17', '2021-08-30 03:33:40'),
(310, 200, 'Yeni destek talebi oluşturuldu #9', '177.130.73.17', '2021-08-30 03:37:06'),
(311, 200, '6 TL tutarında yeni sipariş geçildi #43.', '177.130.73.17', '2021-08-30 03:52:57'),
(312, 200, 'Yeni destek talebi oluşturuldu #10', '177.130.73.17', '2021-08-30 03:58:06'),
(313, 200, 'Destek talebine yanıt verildi #9', '177.130.73.17', '2021-08-30 04:02:00'),
(314, 201, 'Kullanıcı kaydı yapıldı.', '191.189.7.172', '2021-08-30 05:07:43'),
(315, 201, 'Üye girişi yapıldı.', '191.189.7.172', '2021-08-30 05:07:49'),
(316, 202, 'Kullanıcı kaydı yapıldı.', '170.80.76.143', '2021-08-30 05:36:30'),
(317, 202, 'Üye girişi yapıldı.', '170.80.76.143', '2021-08-30 05:36:38'),
(318, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-30 05:36:39'),
(319, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-30 16:35:29'),
(320, 203, 'Kullanıcı kaydı yapıldı.', '170.81.156.145', '2021-08-30 16:38:33'),
(321, 203, 'Üye girişi yapıldı.', '170.81.156.145', '2021-08-30 16:38:48'),
(322, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-30 16:46:16'),
(323, 171, '0.625 TL tutarında yeni sipariş geçildi #44.', '187.19.159.172', '2021-08-30 16:55:21'),
(324, 171, '0.09 TL tutarında yeni sipariş geçildi #45.', '187.19.159.172', '2021-08-30 16:58:27'),
(325, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-30 17:03:07'),
(326, 171, '#44 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-30 17:09:09'),
(327, 171, '#45 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-30 17:11:08'),
(328, 171, 'Üye girişi yapıldı.', '187.19.159.172', '2021-08-30 17:26:49'),
(329, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-30 19:14:16'),
(330, 171, '0.175 TL tutarında yeni sipariş geçildi #46.', '187.19.159.172', '2021-08-30 21:05:44'),
(331, 171, '#46 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-30 21:16:09'),
(332, 200, 'Destek talebine yanıt verildi #9', '177.130.73.17', '2021-08-31 01:02:27'),
(333, 200, 'Destek talebine yanıt verildi #9', '177.130.73.17', '2021-08-31 02:04:49'),
(334, 204, 'Kullanıcı kaydı yapıldı.', '170.83.37.116', '2021-08-31 02:18:59'),
(335, 204, 'Üye girişi yapıldı.', '170.83.37.116', '2021-08-31 02:19:05'),
(336, 205, 'Kullanıcı kaydı yapıldı.', '177.128.199.81', '2021-08-31 04:58:08'),
(337, 205, 'Üye girişi yapıldı.', '177.128.199.81', '2021-08-31 04:58:38'),
(338, 206, 'Kullanıcı kaydı yapıldı.', '177.182.5.14', '2021-08-31 05:53:24'),
(339, 206, 'Üye girişi yapıldı.', '177.182.5.14', '2021-08-31 05:53:37'),
(340, 206, '0 TL tutarında yeni sipariş geçildi #.', '177.182.5.14', '2021-08-31 05:53:55'),
(341, 206, '0 TL tutarında yeni sipariş geçildi #.', '177.182.5.14', '2021-08-31 05:53:58'),
(342, 206, '0 TL tutarında yeni sipariş geçildi #.', '177.182.5.14', '2021-08-31 05:54:04'),
(343, 207, 'Kullanıcı kaydı yapıldı.', '143.255.54.47', '2021-08-31 05:55:38'),
(344, 207, 'Üye girişi yapıldı.', '143.255.54.47', '2021-08-31 05:55:52'),
(345, 171, 'Yönetici girişi yapıldı.', '187.19.159.172', '2021-08-31 05:59:07'),
(346, 208, 'Kullanıcı kaydı yapıldı.', '170.239.17.246', '2021-08-31 06:05:23'),
(347, 209, 'Kullanıcı kaydı yapıldı.', '187.58.182.199', '2021-08-31 06:09:09'),
(348, 209, 'Üye girişi yapıldı.', '187.58.182.199', '2021-08-31 06:09:17'),
(349, 206, 'Üye girişi yapıldı.', '177.182.5.14', '2021-08-31 06:18:01'),
(350, 206, '0 TL tutarında yeni sipariş geçildi #.', '177.182.5.14', '2021-08-31 06:18:22'),
(351, 206, '0 TL tutarında yeni sipariş geçildi #.', '177.182.5.14', '2021-08-31 06:27:40'),
(352, 206, 'Üye girişi yapıldı.', '177.182.5.14', '2021-08-31 06:28:09'),
(353, 206, '17.5 TL tutarında yeni sipariş geçildi #47.', '177.182.5.14', '2021-08-31 06:41:53'),
(354, 206, 'Üye girişi yapıldı.', '177.182.5.14', '2021-08-31 07:04:32'),
(355, 206, '17.5 TL tutarında yeni sipariş geçildi #48.', '177.182.5.14', '2021-08-31 07:04:56'),
(356, 206, '0.035 TL tutarında yeni sipariş geçildi #49.', '177.182.5.14', '2021-08-31 07:06:14'),
(357, 206, '#49 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-31 07:11:09'),
(358, 210, 'Kullanıcı kaydı yapıldı.', '209.58.142.157', '2021-08-31 07:49:09'),
(359, 210, 'Üye girişi yapıldı.', '209.58.142.157', '2021-08-31 07:49:18'),
(360, 211, 'Kullanıcı kaydı yapıldı.', '45.70.190.205', '2021-08-31 09:35:33'),
(361, 211, 'Üye girişi yapıldı.', '45.70.190.205', '2021-08-31 09:36:45'),
(362, 206, '#48 numaralı sipariş tamamlandı.', '127.0.0.1', '2021-08-31 13:01:07'),
(363, 172, '19.2 TL tutarında yeni sipariş geçildi #50.', '187.19.159.213', '2021-08-31 16:21:34'),
(364, 200, 'Destek talebine yanıt verildi #9', '177.130.73.17', '2021-08-31 16:34:07'),
(365, 200, 'Destek talebine yanıt verildi #9', '177.130.73.17', '2021-08-31 16:35:23'),
(366, 200, 'Yeni destek talebi oluşturuldu #11', '177.130.73.17', '2021-08-31 16:41:59'),
(367, 171, 'Yönetici girişi yapıldı.', '45.190.254.145', '2021-08-31 17:00:22'),
(368, 212, 'Kullanıcı kaydı yapıldı.', '200.81.145.10', '2021-08-31 18:57:19'),
(369, 212, 'Üye girişi yapıldı.', '200.81.145.10', '2021-08-31 18:57:27'),
(370, 213, 'Kullanıcı kaydı yapıldı.', '170.244.99.134', '2021-08-31 19:05:53'),
(371, 213, 'Üye girişi yapıldı.', '170.244.99.134', '2021-08-31 19:06:05'),
(372, 214, 'Kullanıcı kaydı yapıldı.', '189.92.208.58', '2021-08-31 19:10:38'),
(373, 172, '19.2 TL tutarında yeni sipariş geçildi #51.', '187.19.159.213', '2021-08-31 20:26:16'),
(374, 171, 'Üye girişi yapıldı.', '187.19.159.4', '2021-08-31 20:34:46'),
(375, 215, 'Kullanıcı kaydı yapıldı.', '179.255.57.96', '2021-08-31 23:36:07'),
(376, 215, 'Üye girişi yapıldı.', '179.255.57.96', '2021-08-31 23:36:38'),
(377, 216, 'Kullanıcı kaydı yapıldı.', '201.182.164.228', '2021-09-01 00:06:48'),
(378, 216, 'Üye girişi yapıldı.', '201.182.164.228', '2021-09-01 00:06:58'),
(379, 213, 'Üye girişi yapıldı.', '170.244.99.134', '2021-09-01 00:26:43'),
(380, 174, '12 TL tutarında yeni sipariş geçildi #52.', '131.196.79.42', '2021-09-01 02:03:44'),
(381, 174, 'Yeni destek talebi oluşturuldu #12', '131.196.79.42', '2021-09-01 02:04:43'),
(382, 174, 'Destek talebine yanıt verildi #12', '131.196.79.42', '2021-09-01 02:09:05'),
(383, 217, 'Kullanıcı kaydı yapıldı.', '45.166.204.188', '2023-01-17 22:05:08'),
(384, 217, 'Üye girişi yapıldı.', '45.166.204.188', '2023-01-17 22:05:15'),
(385, 217, '0.035 TL tutarında yeni sipariş geçildi #53.', '45.166.204.188', '2023-01-17 22:14:38'),
(386, 217, 'Üye girişi yapıldı.', '45.166.204.188', '2023-01-17 22:58:41');

-- --------------------------------------------------------

--
-- Estrutura da tabela `kuponlar`
--

CREATE TABLE `kuponlar` (
  `id` int(11) NOT NULL,
  `kuponadi` varchar(255) NOT NULL,
  `adet` int(11) NOT NULL,
  `tutar` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estrutura da tabela `kupon_kullananlar`
--

CREATE TABLE `kupon_kullananlar` (
  `id` int(11) NOT NULL,
  `uye_id` int(11) NOT NULL,
  `kuponadi` varchar(255) NOT NULL,
  `tutar` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `kupon_kullananlar`
--

INSERT INTO `kupon_kullananlar` (`id`, `uye_id`, `kuponadi`, `tutar`) VALUES
(1, 171, 'DESCONTO ZEYINSTA', 10);

-- --------------------------------------------------------

--
-- Estrutura da tabela `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `language_name` varchar(225) NOT NULL,
  `language_code` varchar(225) NOT NULL,
  `language_type` enum('2','1') NOT NULL DEFAULT '2',
  `default_language` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `languages`
--

INSERT INTO `languages` (`id`, `language_name`, `language_code`, `language_type`, `default_language`) VALUES
(1, 'Türkçe', 'tr', '1', '0'),
(2, 'English', 'en', '2', '1');

-- --------------------------------------------------------

--
-- Estrutura da tabela `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `api_orderid` int(11) NOT NULL DEFAULT 0,
  `order_error` text NOT NULL,
  `order_detail` text DEFAULT NULL,
  `order_api` int(11) NOT NULL DEFAULT 0,
  `api_serviceid` int(11) NOT NULL DEFAULT 0,
  `api_charge` double NOT NULL DEFAULT 0,
  `api_currencycharge` double DEFAULT 1,
  `order_profit` double NOT NULL,
  `order_quantity` double NOT NULL,
  `order_extras` text NOT NULL,
  `order_charge` double NOT NULL,
  `dripfeed` enum('1','2','3') DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `dripfeed_id` double NOT NULL DEFAULT 0,
  `subscriptions_id` double NOT NULL DEFAULT 0,
  `subscriptions_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `dripfeed_totalcharges` double DEFAULT NULL,
  `dripfeed_runs` double DEFAULT NULL,
  `dripfeed_delivery` double NOT NULL DEFAULT 0,
  `dripfeed_interval` double DEFAULT NULL,
  `dripfeed_totalquantity` double DEFAULT NULL,
  `dripfeed_status` enum('active','completed','canceled') NOT NULL DEFAULT 'active',
  `order_url` text NOT NULL,
  `order_start` double NOT NULL DEFAULT 0,
  `order_finish` double NOT NULL DEFAULT 0,
  `order_remains` double NOT NULL DEFAULT 0,
  `order_create` datetime NOT NULL,
  `order_status` enum('pending','inprogress','completed','partial','processing','canceled') NOT NULL DEFAULT 'pending',
  `subscriptions_status` enum('active','paused','completed','canceled','expired','limit') NOT NULL DEFAULT 'active',
  `subscriptions_username` text DEFAULT NULL,
  `subscriptions_posts` double DEFAULT NULL,
  `subscriptions_delivery` double NOT NULL DEFAULT 0,
  `subscriptions_delay` double DEFAULT NULL,
  `subscriptions_min` double DEFAULT NULL,
  `subscriptions_max` double DEFAULT NULL,
  `subscriptions_expiry` date DEFAULT NULL,
  `last_check` datetime NOT NULL,
  `order_where` enum('site','api') NOT NULL DEFAULT 'site'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `pages`
--

CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(225) NOT NULL,
  `page_get` varchar(225) NOT NULL,
  `page_content` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `pages`
--

INSERT INTO `pages` (`page_id`, `page_name`, `page_get`, `page_content`) VALUES
(1, 'Login', 'auth', ''),
(2, 'New Order', 'neworder', '<div class=\"alert alert-danger\" role=\"alert\">\r\n  100% Drop in Bot Followers</div>'),
(3, 'Services', 'services', ''),
(4, 'Add Funds', 'addfunds', ''),
(5, 'Tickets', 'tickets', '<p><br></p>'),
(6, 'Terms', 'terms', '<span style=\"font-size: 30px;\">-Demo Text-</span>'),
(7, 'FAQ', 'faq', '<p><br></p>'),
(8, 'Terms, FAQ', 'terms,faq', '<agrzm>'),
(9, 'Terms, FAQ', 'terms,faq', '<agrzm>');

-- --------------------------------------------------------

--
-- Estrutura da tabela `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL DEFAULT 0,
  `client_balance` double NOT NULL DEFAULT 0,
  `payment_amount` double NOT NULL DEFAULT 0,
  `payment_privatecode` double DEFAULT NULL,
  `payment_method` int(11) NOT NULL DEFAULT -1,
  `payment_status` enum('1','2','3') NOT NULL DEFAULT '1',
  `payment_delivery` enum('1','2') NOT NULL DEFAULT '1',
  `payment_note` text DEFAULT NULL,
  `payment_mode` enum('Manuel','Otomatik') NOT NULL DEFAULT 'Otomatik',
  `payment_create_date` datetime NOT NULL DEFAULT current_timestamp(),
  `payment_update_date` datetime NOT NULL DEFAULT current_timestamp(),
  `payment_ip` varchar(225) DEFAULT NULL,
  `payment_extra` text DEFAULT NULL,
  `payment_bank` int(11) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `payments`
--

INSERT INTO `payments` (`payment_id`, `client_id`, `client_balance`, `payment_amount`, `payment_privatecode`, `payment_method`, `payment_status`, `payment_delivery`, `payment_note`, `payment_mode`, `payment_create_date`, `payment_update_date`, `payment_ip`, `payment_extra`, `payment_bank`) VALUES
(1, 99, 0, 10, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:27:01', '2021-01-02 11:27:01', '157.46.218.211', '356c1b064f73c497eb5f873e20e96493', 0),
(2, 99, 0, 10, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:27:16', '2021-01-02 11:27:16', '157.46.218.211', '5b4634374f3d21e6903ba5ff2b771fa4', 0),
(3, 99, 0, 10, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:34:08', '2021-01-02 11:34:08', '157.46.218.211', 'c2e03bf3ce4a2136096b81c5e5b7f6c2', 0),
(4, 99, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:34:19', '2021-01-02 11:34:19', '157.46.218.211', '111a37f89ff189fdcd6803b6b0073f2b', 0),
(5, 99, 0, 1, NULL, 12, '1', '1', NULL, 'Otomatik', '2021-01-02 11:40:05', '2021-01-02 11:40:05', '157.46.218.211', 'ORDS11779', 0),
(9, 99, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:47:42', '2021-01-02 11:47:42', '157.46.218.211', 'be2d4931cf9fb069c3fa137480519d15', 0),
(10, 99, 0, 1, NULL, 1, '1', '1', NULL, '', '2021-01-02 11:49:43', '2021-01-02 11:49:43', '157.46.218.211', 'a3a85806e3ad2e9b6e47c1a937269a3e', 0),
(11, 99, 0, 1, NULL, 15, '1', '1', NULL, 'Otomatik', '2021-01-02 11:50:07', '2021-01-02 11:50:07', '157.46.218.211', '1609568407', 0),
(12, 99, 0, 10, NULL, 15, '1', '1', NULL, 'Otomatik', '2021-01-02 11:50:48', '2021-01-02 11:50:48', '157.46.218.211', '1609568448', 0),
(13, 99, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:51:25', '2021-01-02 11:51:25', '157.46.218.211', '212c417c403b16172a404c6fa5e4ccf7', 0),
(14, 99, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-02 11:54:31', '2021-01-02 11:54:31', '157.46.218.211', 'accfa83cd7c1d7e675448b4dfefbf6ed', 0),
(15, 162, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-09 12:00:44', '2021-01-09 12:00:44', '157.42.25.191', 'dd58bc4e0223433d6e27bfa8a38c7888', 0),
(16, 162, 0, 1, NULL, 12, '1', '1', NULL, 'Otomatik', '2021-01-09 12:01:04', '2021-01-09 12:01:04', '157.42.25.191', 'ORDS48203724', 0),
(17, 162, 0, 1, NULL, 1, '1', '1', NULL, '', '2021-01-09 12:01:32', '2021-01-09 12:01:32', '157.42.25.191', '53935e50823611adc250275a91e8c152', 0),
(18, 162, 0, 1, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-09 12:01:53', '2021-01-09 12:01:53', '157.42.25.191', '6661e0f6784baec5f1a14ce4bc6c879e', 0),
(19, 99, 0, 20, NULL, 15, '1', '1', NULL, 'Otomatik', '2021-01-30 19:23:07', '2021-01-30 19:23:07', '::1', '1612014787', 0),
(20, 99, 0, 20, NULL, 9, '1', '1', NULL, '', '2021-01-30 19:23:30', '2021-01-30 19:23:30', '::1', 'dca335bee55d1f0276097a83802953e3', 0),
(21, 99, 0, 26, NULL, 12, '1', '1', NULL, 'Otomatik', '2021-01-30 19:23:57', '2021-01-30 19:23:57', '::1', 'ORDS12001877', 0),
(22, 99, 0, 34, NULL, 13, '1', '1', NULL, 'Otomatik', '2021-01-30 19:24:03', '2021-01-30 19:24:03', '::1', '16b1afd380908553f25a7afa56c82f7e', 0),
(23, 171, 0, 12, NULL, 16, '1', '1', NULL, '', '2021-08-12 00:16:28', '2021-08-11 15:46:28', '187.19.159.172', 'df59bd7cc54bba97967dde0205cea29f', 0),
(24, 171, 0, 1.01, NULL, 16, '3', '2', NULL, '', '2021-08-12 07:07:03', '2021-08-11 22:37:03', '187.19.159.172', 'Array', 0),
(25, 171, 0, 1.01, NULL, 16, '1', '1', NULL, '', '2021-08-12 07:08:14', '2021-08-11 22:38:14', '187.19.159.172', '744d56c9172a10db598f22ebabf001b8', 0),
(26, 171, 0, 50.5, NULL, 16, '1', '1', NULL, '', '2021-08-12 07:10:07', '2021-08-11 22:40:07', '187.19.159.172', 'cb276e177f8f689e9ac8d166ff62a3d4', 0),
(27, 171, 0, 0.505, NULL, 16, '1', '1', NULL, '', '2021-08-12 07:10:20', '2021-08-11 22:40:20', '187.19.159.172', 'b465642abbf1c9b0fdff2554b8cb3079', 0),
(28, 171, 0, 0.505, NULL, 16, '1', '1', NULL, '', '2021-08-12 07:10:54', '2021-08-11 22:40:54', '187.19.159.172', '5ff4f92b8d639c54b6bd4f08a5b90f8b', 0),
(29, 171, 0, 1.01, NULL, 16, '1', '1', NULL, '', '2021-08-12 07:11:15', '2021-08-11 22:41:15', '187.19.159.172', '5aff46ac5506811931227b73dc8fad09', 0),
(30, 171, 0, 1.01, NULL, 16, '1', '1', NULL, '', '2021-08-12 07:12:04', '2021-08-11 22:42:04', '187.19.159.172', 'a281f8bc643353ccfed47abfac90c399', 0),
(31, 171, 0, 1.01, NULL, 16, '1', '1', NULL, '', '2021-08-12 07:12:16', '2021-08-11 22:42:16', '187.19.159.172', '924ef1fba2cdf2b023ca746807844cc9', 0),
(32, 171, 0, 1.515, NULL, 16, '1', '1', NULL, '', '2021-08-12 07:14:13', '2021-08-11 22:44:13', '187.19.159.172', '73ce59177fd03b76fa1d3f114c12a52b', 0),
(33, 171, 0, 1.01, NULL, 16, '1', '1', NULL, '', '2021-08-12 07:16:17', '2021-08-11 22:46:17', '187.19.159.172', 'ee5ff3f3c75d7a57fcf77565f504ae7b', 0),
(34, 171, 0, 5.05, NULL, 16, '3', '2', NULL, '', '2021-08-12 07:23:11', '2021-08-11 22:53:11', '187.19.159.172', 'Array', 0),
(35, 171, 0, 5.05, NULL, 16, '1', '1', NULL, '', '2021-08-12 07:23:52', '2021-08-11 22:53:52', '187.19.159.172', 'aae697fce6f00c7a662cb0893c602a91', 0),
(36, 171, 0, 1.01, NULL, 16, '1', '1', NULL, '', '2021-08-12 08:45:22', '2021-08-12 00:15:22', '187.19.159.172', '05084854b71370afa6c2dd55bd8f794e', 0),
(37, 171, 0, 1.01, NULL, 16, '1', '1', NULL, '', '2021-08-12 08:45:54', '2021-08-12 00:15:54', '187.19.159.172', '22e03acebae1978b077903cb48f963e6', 0),
(38, 171, 0, 1.01, NULL, 16, '1', '1', NULL, '', '2021-08-12 08:48:10', '2021-08-12 00:18:10', '187.19.159.172', '8bd659fdc1890304dd529b805b99f1e8', 0),
(39, 175, 0, 10.1, NULL, 16, '1', '1', NULL, '', '2021-08-13 09:09:33', '2021-08-13 00:39:33', '179.240.24.113', '9a161912b0f3ea06a0be4e5dcd8f499e', 0),
(40, 174, 0, 28, 0, 16, '3', '2', '', 'Manuel', '2021-08-15 15:01:57', '2021-08-15 15:01:57', '187.19.159.172', ' sad', 0),
(41, 180, 0, 10.1, NULL, 16, '1', '1', NULL, '', '2021-08-15 22:25:16', '2021-08-15 13:55:16', '45.190.254.100', '5e58c5cba96e6ba3caab5ef5e11cedc9', 0),
(42, 180, 0, 10.1, NULL, 16, '1', '1', NULL, '', '2021-08-17 00:11:03', '2021-08-16 15:41:03', '45.190.254.244', '8552648446f7ed3c12dd4f779ae9c723', 0),
(43, 180, 0, 10.1, NULL, 16, '1', '1', NULL, '', '2021-08-17 00:13:12', '2021-08-16 15:43:12', '45.190.254.244', '850c75ec70b72127ec42faef3d6bb573', 0),
(44, 171, 0, 10.1, NULL, 16, '1', '1', NULL, '', '2021-08-20 02:47:14', '2021-08-19 18:17:14', '45.165.24.38', '31ea1327ee12a33aafcbcdbe3d7d6a01', 0),
(45, 184, 0, 20.2, NULL, 16, '3', '2', '', '', '2021-08-21 20:56:28', '2021-08-21 22:10:19', '187.7.230.2', 'Array', 0),
(46, 184, 0, 20.2, NULL, 16, '1', '1', NULL, '', '2021-08-21 20:59:25', '2021-08-21 12:29:25', '187.7.230.2', '32510ce9c7abccd6ea28b4b80bcd362b', 0),
(47, 184, 0, 20.2, NULL, 16, '3', '2', NULL, '', '2021-08-22 07:24:22', '2021-08-21 22:54:22', '45.6.111.242', 'Array', 0),
(48, 184, 0, 20.2, NULL, 16, '1', '1', NULL, '', '2021-08-22 07:25:45', '2021-08-21 22:55:45', '45.6.111.242', 'd7698cb17c0a252660f30655fc54f319', 0),
(49, 184, 0, 20.2, NULL, 16, '3', '2', NULL, '', '2021-08-24 06:46:41', '2021-08-23 22:16:41', '45.6.111.242', 'Array', 0),
(50, 184, 0, 20.2, NULL, 16, '1', '1', NULL, '', '2021-08-24 06:48:46', '2021-08-23 22:18:46', '45.6.111.242', 'd51d75fb8dd668f66b0988ae43b80ebe', 0),
(51, 171, 0, 10.1, NULL, 16, '1', '1', NULL, '', '2021-08-25 21:15:46', '2021-08-25 12:45:46', '187.19.159.28', '69be74088189adcd44673ad868fec3f7', 0),
(52, 171, 0, 25.25, NULL, 16, '1', '1', NULL, '', '2021-08-29 02:23:15', '2021-08-28 17:53:15', '187.19.159.172', '646a0d2d77d44faf76abaaad5a6f0b4c', 0),
(53, 194, 0, 30.3, NULL, 16, '1', '1', NULL, '', '2021-08-29 02:39:50', '2021-08-28 18:09:50', '45.190.252.162', '3e7ab4a92bf4b832910cb098a545e6aa', 0),
(54, 200, 0, 20, NULL, 16, '3', '2', NULL, '', '2021-08-30 03:49:11', '2021-08-29 19:19:11', '177.130.73.17', 'Array', 0),
(55, 201, 0, 20, NULL, 16, '1', '1', NULL, '', '2021-08-30 05:09:01', '2021-08-29 20:39:01', '191.189.7.172', 'b602ba298d9d297f78ab72314f4328b9', 0),
(56, 171, 0, 20, NULL, 16, '1', '1', NULL, '', '2021-08-30 16:36:44', '2021-08-30 08:06:44', '187.19.159.172', '0a9f021ee6c6e41a1a7d42dcca6faeca', 0),
(57, 171, 0, 20, NULL, 16, '1', '1', NULL, '', '2021-08-30 16:48:33', '2021-08-30 08:18:33', '187.19.159.172', 'abbdd9750444d6893119010b5a0f17bb', 0),
(58, 171, 0, 20, NULL, 16, '1', '1', NULL, '', '2021-08-30 17:04:31', '2021-08-30 08:34:31', '187.19.159.172', '28574ef707ce0c7c1eca1068dae09603', 0),
(59, 171, 0, 20, NULL, 16, '1', '1', NULL, '', '2021-08-31 06:24:52', '2021-08-30 21:54:52', '187.19.159.172', '5ec2ffe6ed2a3d331a82a178d5f5b1c6', 0),
(60, 206, 0, 20, 0, 16, '3', '2', '', 'Manuel', '2021-08-31 06:38:42', '2021-08-31 06:38:42', '187.19.159.172', ' sad', 0),
(61, 172, 0, 20, NULL, 16, '3', '2', NULL, '', '2021-08-31 16:19:57', '2021-08-31 07:49:57', '187.19.159.213', 'Array', 0),
(62, 172, 0, 20, NULL, 16, '1', '1', NULL, '', '2021-08-31 16:20:39', '2021-08-31 07:50:39', '187.19.159.213', 'c8f2f4ab9084ae7b5109111e5fe69e67', 0),
(63, 213, 0, 20, NULL, 16, '1', '1', NULL, '', '2021-08-31 19:07:26', '2021-08-31 10:37:26', '170.244.99.134', 'c7bc23269402bdf252e8100646e4167b', 0),
(64, 217, 0, 20, NULL, 16, '1', '1', NULL, '', '2023-01-17 22:05:34', '2023-01-17 16:35:34', '45.166.204.188', 'eb3698e220f37162f254b9f0f9175936', 0),
(65, 217, 0, 20, NULL, 16, '1', '1', NULL, '', '2023-01-17 22:07:37', '2023-01-17 16:37:37', '45.166.204.188', '9fe874f75b972302a5635be2d96e6f4c', 0),
(66, 217, 0, 1, NULL, 16, '3', '2', NULL, '', '2023-01-17 22:11:45', '2023-01-17 16:41:45', '45.166.204.188', 'Array', 0),
(67, 217, 0, 10, NULL, 16, '1', '1', NULL, '', '2023-01-17 22:59:11', '2023-01-17 17:29:11', '45.166.204.188', '5ae4e3a472cff31c99b37012e2179421', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `payments_bonus`
--

CREATE TABLE `payments_bonus` (
  `bonus_id` int(11) NOT NULL,
  `bonus_method` int(11) NOT NULL,
  `bonus_from` double NOT NULL,
  `bonus_amount` double NOT NULL,
  `bonus_type` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `method_name` varchar(225) NOT NULL,
  `method_get` varchar(225) NOT NULL,
  `method_min` double NOT NULL,
  `method_max` double NOT NULL,
  `method_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF	',
  `method_extras` text NOT NULL,
  `method_line` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `method_name`, `method_get`, `method_min`, `method_max`, `method_type`, `method_extras`, `method_line`) VALUES
(1, 'Paypal', 'paypal', 1, 0, '1', '{\"method_type\":\"2\",\"name\":\"Paypal\",\"min\":\"1\",\"max\":\"0\",\"client_id\":\"\",\"client_secret\":\"\",\"fee\":\"5\"}', 3),
(3, 'Shopier', 'shopier', 5, 0, '1', '{\"method_type\":\"2\",\"name\":\"Shopier\",\"min\":\"5\",\"max\":\"0\",\"apiKey\":\"\",\"apiSecret\":\"\",\"website_index\":\"1\",\"processing_fee\":\"1\",\"fee\":\"0\"}', 4),
(6, 'Manual Transfer(Bank)', 'havale-eft', 0, 0, '1', '{\"method_type\":\"2\",\"name\":\"Manual Transfer(Bank)\"}', 5),
(8, 'Coinpayments', 'coinpayments', 1, 0, '1', '{\"method_type\":\"2\",\"name\":\"Coinpayments\",\"min\":\"1\",\"max\":\"0\",\"coinpayments_public_key\":\"\",\"coinpayments_private_key\":\"\",\"coinpayments_currency\":\"BTC\",\"merchant_id\":\"\",\"ipn_secret\":\"\",\"fee\":\"0\"}', 6),
(9, '2checkout', '2checkout', 1, 0, '1', '{\"method_type\":\"2\",\"name\":\"2checkout\",\"min\":\"1\",\"max\":\"0\",\"seller_id\":\"\",\"private_key\":\"\",\"fee\":\"0\"}', 7),
(10, 'Payoneer', 'payoneer', 0, 0, '1', '{\"method_type\":\"2\",\"name\":\"Payoneer\",\"email\":\"admin@gmail.com\"}', 8),
(11, 'Mollie', 'mollie', 1, 0, '1', '{\"method_type\":\"2\",\"name\":\"Mollie\",\"min\":\"1\",\"max\":\"0\",\"live_api_key\":\"\",\"fee\":\"0\"}', 9),
(12, 'PayTM', 'paytm', 1, 10000, '1', '{\"method_type\":\"2\",\"name\":\"PayTM\",\"min\":\"1\",\"max\":\"10000\",\"merchant_key\":\"\",\"merchant_mid\":\"\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\"}', 2),
(13, 'RazorPay', 'razorpay', 1, 0, '1', '{\"method_type\":\"2\",\"name\":\"Razorpay\",\"min\":\"1\",\"max\":\"0\",\"public_key\":\"\",\"key_secret\":\"\",\"merchant_website\":\"https:\\/\\/api.razorpay.com\\/v1\\/orders\",\"fee\":\"0\"}', 1),
(14, 'PayTM QR', 'paytmqr', 1, 0, '1', '{\"method_type\":\"2\",\"name\":\"PayTMQR\",\"min\":\"1\",\"max\":\"0\",\"merchant_key\":\"\\/img\\/paytm_qr.png\",\"merchant_mid\":\"\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\"}', 10),
(15, 'Perfect Money', 'perfectmoney', 0, 10000, '1', '{\"method_type\":\"2\",\"name\":\"Perfect Money\",\"min\":\"0\",\"max\":\"10000\",\"passphrase\":\"\",\"usd\":\"\",\"merchant_website\":\"\",\"fee\":\"0\"}', 10),
(16, 'PIX', 'pix_auto', 1, 10000, '2', '{\"method_type\":\"2\",\"name\":\"PIX - Autom\\u00e1tico ( M\\u00edn. R$ 1.00 )\",\"min\":\"1\",\"max\":\"10000\",\"access_token\":\"APP_USR-1043540912615005-121719-016a8bfed6a185b96c9c71d1441297f8-1041647728\",\"fee\":\"0\"}', 11);

-- --------------------------------------------------------

--
-- Estrutura da tabela `serviceapi_alert`
--

CREATE TABLE `serviceapi_alert` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `serviceapi_alert` text NOT NULL,
  `servicealert_extra` text NOT NULL,
  `servicealert_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `serviceapi_alert`
--

INSERT INTO `serviceapi_alert` (`id`, `service_id`, `serviceapi_alert`, `servicealert_extra`, `servicealert_date`) VALUES
(2, 407, '#407 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-13 10:47:14'),
(3, 407, '#407 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-13 10:48:12'),
(4, 407, '#407 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-13 14:08:03'),
(5, 409, '#409 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-13 16:26:10'),
(6, 405, '#405 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-14 04:48:07'),
(7, 405, '#405 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-14 04:49:08'),
(8, 406, '#406 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-14 18:01:09'),
(9, 410, '#410 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-15 00:34:13'),
(10, 523, '#523 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-15 09:21:25'),
(11, 523, '#523 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-15 09:22:09'),
(12, 431, '#431 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-15 09:23:11'),
(13, 411, '#411 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 05:06:12'),
(14, 411, '#411 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 15:52:03'),
(15, 411, '#411 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 15:53:01'),
(16, 405, '#405 numaralı servis fiyatı değiştirilmiş.', '{\"old\":34.10000000000000142108547152020037174224853515625,\"new\":36.2999999999999971578290569595992565155029296875}', '2021-08-16 19:43:04'),
(17, 405, '#405 numaralı servis fiyatı değiştirilmiş.', '{\"old\":36.2999999999999971578290569595992565155029296875,\"new\":38.5}', '2021-08-16 19:46:11'),
(18, 410, '#410 numaralı servis fiyatı değiştirilmiş.', '{\"old\":16.5,\"new\":20.89999999999999857891452847979962825775146484375}', '2021-08-16 19:47:07'),
(19, 405, '#405 numaralı servis fiyatı değiştirilmiş.', '{\"old\":36.2999999999999971578290569595992565155029296875,\"new\":38.5}', '2021-08-16 19:47:08'),
(20, 504, '#504 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:12:07'),
(21, 504, '#504 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:13:08'),
(22, 429, '#429 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:13:12'),
(23, 439, '#439 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:13:12'),
(24, 456, '#456 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:13:12'),
(25, 487, '#487 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:13:12'),
(26, 522, '#522 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:14:07'),
(27, 519, '#519 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:14:07'),
(28, 510, '#510 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:14:07'),
(29, 423, '#423 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:14:07'),
(30, 436, '#436 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:14:07'),
(31, 446, '#446 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:14:07'),
(32, 459, '#459 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:14:07'),
(33, 464, '#464 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:14:07'),
(34, 473, '#473 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:14:07'),
(35, 486, '#486 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:14:07'),
(36, 522, '#522 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:14:10'),
(37, 519, '#519 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:14:11'),
(38, 510, '#510 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:14:15'),
(39, 423, '#423 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:14:22'),
(40, 436, '#436 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:14:28'),
(41, 446, '#446 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:14:33'),
(42, 459, '#459 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:14:39'),
(43, 439, '#439 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:15:05'),
(44, 454, '#454 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:15:05'),
(45, 490, '#490 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:15:05'),
(46, 504, '#504 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:15:05'),
(47, 439, '#439 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:15:34'),
(48, 454, '#454 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:15:41'),
(49, 464, '#464 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:15:46'),
(50, 490, '#490 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:15:58'),
(51, 504, '#504 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:16:05'),
(52, 507, '#507 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:16:09'),
(53, 426, '#426 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:16:09'),
(54, 440, '#440 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:16:09'),
(55, 450, '#450 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:16:09'),
(56, 459, '#459 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:16:09'),
(57, 462, '#462 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:16:09'),
(58, 472, '#472 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:16:09'),
(59, 487, '#487 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:16:09'),
(60, 497, '#497 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:16:09'),
(61, 507, '#507 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:16:21'),
(62, 426, '#426 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:16:27'),
(63, 459, '#459 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:16:43'),
(64, 462, '#462 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:16:44'),
(65, 472, '#472 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:16:49'),
(66, 487, '#487 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:16:57'),
(67, 497, '#497 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:17:01'),
(68, 429, '#429 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:17:09'),
(69, 485, '#485 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:17:09'),
(70, 486, '#486 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:17:09'),
(71, 440, '#440 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:17:31'),
(72, 450, '#450 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:17:36'),
(73, 520, '#520 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:18:07'),
(74, 519, '#519 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:18:07'),
(75, 467, '#467 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:18:07'),
(76, 483, '#483 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:18:07'),
(77, 497, '#497 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:18:07'),
(78, 520, '#520 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:18:13'),
(79, 519, '#519 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:18:13'),
(80, 467, '#467 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:18:45'),
(81, 483, '#483 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:18:53'),
(82, 497, '#497 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:18:59'),
(83, 426, '#426 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:19:07'),
(84, 430, '#430 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:19:07'),
(85, 442, '#442 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:19:07'),
(86, 452, '#452 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:19:07'),
(87, 459, '#459 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:19:07'),
(88, 470, '#470 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:19:07'),
(89, 493, '#493 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:19:07'),
(90, 426, '#426 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:19:25'),
(91, 430, '#430 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:19:27'),
(92, 442, '#442 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:19:33'),
(93, 452, '#452 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:19:38'),
(94, 470, '#470 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:19:47'),
(95, 493, '#493 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:19:58'),
(96, 506, '#506 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:20:08'),
(97, 429, '#429 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:20:08'),
(98, 435, '#435 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:20:08'),
(99, 483, '#483 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:20:08'),
(100, 506, '#506 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:20:21'),
(101, 429, '#429 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:20:28'),
(102, 435, '#435 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:20:31'),
(103, 459, '#459 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:20:42'),
(104, 483, '#483 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:20:54'),
(105, 455, '#455 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:21:08'),
(106, 462, '#462 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:21:08'),
(107, 492, '#492 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:21:08'),
(108, 455, '#455 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:21:39'),
(109, 462, '#462 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:21:43'),
(110, 511, '#511 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:22:08'),
(111, 445, '#445 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:22:08'),
(112, 467, '#467 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:22:08'),
(113, 502, '#502 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:22:08'),
(114, 511, '#511 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:22:17'),
(115, 445, '#445 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:22:34'),
(116, 467, '#467 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:22:45'),
(117, 492, '#492 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:22:57'),
(118, 502, '#502 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:23:03'),
(119, 516, '#516 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:23:08'),
(120, 426, '#426 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:23:08'),
(121, 431, '#431 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:23:08'),
(122, 437, '#437 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:23:08'),
(123, 461, '#461 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:23:08'),
(124, 491, '#491 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:23:08'),
(125, 505, '#505 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:23:08'),
(126, 516, '#516 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:23:15'),
(127, 426, '#426 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:23:25'),
(128, 431, '#431 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:23:27'),
(129, 461, '#461 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:23:42'),
(130, 491, '#491 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:23:56'),
(131, 505, '#505 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:24:03'),
(132, 521, '#521 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:24:06'),
(133, 511, '#511 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:24:06'),
(134, 509, '#509 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:24:06'),
(135, 423, '#423 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:24:06'),
(136, 425, '#425 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:24:06'),
(137, 447, '#447 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:24:06'),
(138, 476, '#476 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:24:06'),
(139, 493, '#493 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:24:06'),
(140, 521, '#521 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:24:11'),
(141, 511, '#511 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:24:16'),
(142, 509, '#509 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:24:17'),
(143, 423, '#423 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:24:22'),
(144, 425, '#425 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:24:23'),
(145, 437, '#437 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:24:29'),
(146, 447, '#447 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:24:34'),
(147, 476, '#476 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:24:48'),
(148, 493, '#493 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:24:56'),
(149, 516, '#516 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:25:06'),
(150, 431, '#431 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:25:06'),
(151, 468, '#468 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:25:06'),
(152, 480, '#480 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:25:06'),
(153, 498, '#498 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:25:06'),
(154, 516, '#516 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:25:15'),
(155, 431, '#431 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:25:27'),
(156, 468, '#468 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:25:45'),
(157, 480, '#480 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:25:51'),
(158, 498, '#498 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:26:00'),
(159, 423, '#423 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:26:07'),
(160, 446, '#446 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:26:07'),
(161, 502, '#502 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:26:07'),
(162, 423, '#423 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:26:22'),
(163, 446, '#446 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:26:33'),
(164, 502, '#502 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:27:00'),
(165, 522, '#522 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:27:05'),
(166, 513, '#513 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:27:05'),
(167, 420, '#420 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:27:05'),
(168, 432, '#432 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:27:05'),
(169, 437, '#437 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:27:05'),
(170, 447, '#447 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:27:05'),
(171, 468, '#468 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:27:05'),
(172, 482, '#482 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:27:05'),
(173, 494, '#494 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:27:05'),
(174, 522, '#522 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:27:11'),
(175, 513, '#513 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:27:16'),
(176, 420, '#420 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:27:21'),
(177, 432, '#432 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:27:27'),
(178, 437, '#437 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:27:29'),
(179, 447, '#447 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:27:34'),
(180, 468, '#468 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:27:44'),
(181, 482, '#482 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:27:51'),
(182, 494, '#494 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:27:57'),
(183, 516, '#516 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:28:06'),
(184, 506, '#506 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:28:06'),
(185, 418, '#418 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:28:06'),
(186, 429, '#429 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:28:06'),
(187, 430, '#430 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:28:06'),
(188, 516, '#516 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:28:15'),
(189, 506, '#506 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:28:20'),
(190, 418, '#418 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:28:21'),
(191, 429, '#429 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:28:26'),
(192, 430, '#430 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:28:27'),
(193, 426, '#426 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:29:07'),
(194, 462, '#462 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:29:07'),
(195, 467, '#467 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:29:07'),
(196, 474, '#474 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:29:07'),
(197, 479, '#479 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:29:07'),
(198, 491, '#491 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:29:07'),
(199, 426, '#426 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:29:26'),
(200, 462, '#462 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:29:43'),
(201, 467, '#467 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:29:45'),
(202, 479, '#479 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:29:51'),
(203, 491, '#491 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:29:57'),
(204, 424, '#424 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:30:07'),
(205, 444, '#444 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:30:07'),
(206, 449, '#449 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:30:07'),
(207, 456, '#456 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:30:07'),
(208, 461, '#461 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:30:07'),
(209, 500, '#500 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:30:07'),
(210, 424, '#424 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:30:23'),
(211, 444, '#444 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:30:33'),
(212, 449, '#449 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:30:36'),
(213, 456, '#456 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:30:39'),
(214, 461, '#461 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:30:41'),
(215, 474, '#474 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:30:43'),
(216, 474, '#474 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:30:47'),
(217, 500, '#500 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:31:00'),
(218, 422, '#422 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:00'),
(219, 424, '#424 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:00'),
(220, 452, '#452 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:00'),
(221, 453, '#453 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:00'),
(222, 467, '#467 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:00'),
(223, 487, '#487 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:00'),
(224, 492, '#492 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:00'),
(225, 517, '#517 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:07'),
(226, 510, '#510 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:07'),
(227, 448, '#448 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:07'),
(228, 464, '#464 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:07'),
(229, 485, '#485 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:07'),
(230, 498, '#498 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:31:07'),
(231, 517, '#517 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:31:15'),
(232, 510, '#510 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:31:18'),
(233, 422, '#422 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:31:24'),
(234, 424, '#424 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:31:25'),
(235, 448, '#448 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:31:37'),
(236, 452, '#452 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:31:39'),
(237, 453, '#453 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:31:40'),
(239, 467, '#467 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:31:47'),
(240, 485, '#485 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:31:56'),
(241, 492, '#492 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:32:00'),
(242, 498, '#498 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:32:03'),
(243, 524, '#524 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:32:11'),
(244, 447, '#447 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:32:11'),
(245, 493, '#493 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:32:11'),
(246, 487, '#487 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:32:53'),
(247, 422, '#422 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:33:05'),
(248, 431, '#431 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:33:05'),
(249, 460, '#460 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:33:05'),
(250, 485, '#485 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:33:05'),
(251, 524, '#524 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:33:11'),
(252, 422, '#422 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:33:24'),
(253, 485, '#485 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:33:55'),
(254, 507, '#507 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:34:08'),
(255, 428, '#428 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:34:08'),
(256, 440, '#440 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:34:08');
INSERT INTO `serviceapi_alert` (`id`, `service_id`, `serviceapi_alert`, `servicealert_extra`, `servicealert_date`) VALUES
(257, 450, '#450 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:34:08'),
(258, 471, '#471 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:34:08'),
(259, 473, '#473 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:34:08'),
(260, 482, '#482 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:34:08'),
(261, 507, '#507 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:34:19'),
(262, 428, '#428 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:34:26'),
(263, 431, '#431 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:34:27'),
(264, 440, '#440 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:34:32'),
(265, 450, '#450 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:34:36'),
(266, 460, '#460 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:34:41'),
(267, 471, '#471 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:34:47'),
(268, 473, '#473 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:34:48'),
(269, 482, '#482 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:34:52'),
(270, 516, '#516 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:35:06'),
(271, 470, '#470 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:35:06'),
(272, 500, '#500 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:35:06'),
(273, 516, '#516 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:35:16'),
(274, 500, '#500 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:36:03'),
(275, 507, '#507 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:36:09'),
(276, 454, '#454 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:36:09'),
(277, 460, '#460 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:36:09'),
(278, 470, '#470 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:36:44'),
(279, 515, '#515 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:37:04'),
(280, 438, '#438 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:37:04'),
(281, 462, '#462 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:37:04'),
(282, 485, '#485 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:37:04'),
(283, 515, '#515 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:37:15'),
(284, 438, '#438 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:37:31'),
(285, 462, '#462 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:37:42'),
(286, 485, '#485 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:37:53'),
(287, 451, '#451 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:38:07'),
(288, 467, '#467 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:38:07'),
(289, 490, '#490 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:38:07'),
(290, 502, '#502 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:38:07'),
(291, 451, '#451 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:38:38'),
(292, 467, '#467 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:38:45'),
(293, 490, '#490 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:38:57'),
(294, 502, '#502 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:39:03'),
(295, 519, '#519 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:39:07'),
(296, 507, '#507 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:39:07'),
(297, 437, '#437 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:39:07'),
(298, 461, '#461 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:39:07'),
(299, 496, '#496 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:39:07'),
(300, 519, '#519 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:39:14'),
(301, 507, '#507 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:39:20'),
(302, 437, '#437 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:39:30'),
(303, 461, '#461 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:39:42'),
(304, 496, '#496 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:39:59'),
(305, 526, '#526 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:40:07'),
(306, 515, '#515 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:40:07'),
(307, 433, '#433 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:40:07'),
(308, 445, '#445 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:40:07'),
(309, 456, '#456 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:40:07'),
(310, 468, '#468 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:40:07'),
(311, 526, '#526 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:40:10'),
(312, 515, '#515 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:40:16'),
(313, 433, '#433 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:40:29'),
(314, 445, '#445 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:40:35'),
(315, 456, '#456 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:40:40'),
(316, 468, '#468 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:40:46'),
(317, 508, '#508 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:41:08'),
(318, 429, '#429 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:41:08'),
(319, 478, '#478 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:41:08'),
(320, 485, '#485 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:41:08'),
(321, 503, '#503 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:41:08'),
(322, 514, '#514 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:42:05'),
(323, 511, '#511 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:42:05'),
(324, 420, '#420 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:42:05'),
(325, 431, '#431 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:42:05'),
(326, 452, '#452 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:42:05'),
(327, 463, '#463 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:42:05'),
(328, 480, '#480 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:42:05'),
(329, 492, '#492 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:42:05'),
(330, 505, '#505 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:42:05'),
(331, 514, '#514 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:42:14'),
(332, 511, '#511 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:42:15'),
(333, 420, '#420 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:42:20'),
(334, 431, '#431 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:42:25'),
(335, 463, '#463 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:42:41'),
(336, 480, '#480 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:42:49'),
(337, 492, '#492 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:42:55'),
(338, 505, '#505 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:43:01'),
(339, 517, '#517 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:43:05'),
(340, 419, '#419 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:43:05'),
(341, 429, '#429 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:43:05'),
(342, 462, '#462 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:43:05'),
(343, 470, '#470 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:43:05'),
(344, 481, '#481 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:43:05'),
(345, 517, '#517 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:43:14'),
(346, 419, '#419 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:43:21'),
(347, 429, '#429 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:43:26'),
(348, 452, '#452 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:43:37'),
(349, 462, '#462 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:43:42'),
(350, 481, '#481 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:43:51'),
(351, 521, '#521 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:44:07'),
(352, 512, '#512 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:44:07'),
(353, 493, '#493 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:44:07'),
(354, 495, '#495 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:44:07'),
(355, 521, '#521 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:44:12'),
(356, 512, '#512 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:44:17'),
(357, 470, '#470 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:44:46'),
(358, 493, '#493 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:44:57'),
(359, 495, '#495 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:44:58'),
(360, 507, '#507 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:45:07'),
(361, 431, '#431 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:45:07'),
(362, 440, '#440 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:45:07'),
(363, 454, '#454 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:45:07'),
(364, 464, '#464 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:45:07'),
(365, 466, '#466 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:45:07'),
(366, 491, '#491 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:45:07'),
(367, 502, '#502 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:45:07'),
(368, 503, '#503 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:45:07'),
(369, 507, '#507 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:45:20'),
(370, 431, '#431 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:45:28'),
(371, 440, '#440 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:45:33'),
(372, 464, '#464 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:45:44'),
(373, 466, '#466 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:45:45'),
(374, 491, '#491 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:45:57'),
(375, 502, '#502 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:46:03'),
(376, 503, '#503 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:46:03'),
(377, 523, '#523 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:46:08'),
(378, 514, '#514 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:46:08'),
(379, 512, '#512 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:46:08'),
(380, 425, '#425 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:46:08'),
(381, 432, '#432 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:46:08'),
(382, 478, '#478 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:46:08'),
(383, 523, '#523 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:46:10'),
(384, 514, '#514 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:46:14'),
(385, 512, '#512 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:46:16'),
(386, 425, '#425 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:46:23'),
(387, 454, '#454 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:46:37'),
(388, 478, '#478 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:46:48'),
(389, 515, '#515 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:47:05'),
(390, 441, '#441 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:47:05'),
(391, 451, '#451 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:47:05'),
(392, 461, '#461 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:47:05'),
(393, 470, '#470 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:47:06'),
(394, 480, '#480 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:47:06'),
(395, 492, '#492 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:47:06'),
(396, 515, '#515 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:47:14'),
(397, 432, '#432 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:47:26'),
(398, 441, '#441 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:47:31'),
(399, 451, '#451 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:47:36'),
(400, 461, '#461 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:47:40'),
(401, 470, '#470 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:47:45'),
(402, 480, '#480 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:47:50'),
(403, 492, '#492 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:47:55'),
(404, 516, '#516 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:48:06'),
(405, 494, '#494 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:48:06'),
(406, 501, '#501 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:48:06'),
(407, 505, '#505 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:48:06'),
(408, 516, '#516 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:48:15'),
(409, 494, '#494 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:48:59'),
(410, 501, '#501 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:49:02'),
(411, 505, '#505 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:49:04'),
(412, 523, '#523 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:49:08'),
(413, 518, '#518 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:49:08'),
(414, 507, '#507 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:49:08'),
(415, 421, '#421 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:49:08'),
(416, 435, '#435 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:49:08'),
(417, 444, '#444 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:49:08'),
(418, 465, '#465 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:49:08'),
(419, 476, '#476 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:49:08'),
(420, 498, '#498 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:49:08'),
(421, 503, '#503 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:49:08'),
(422, 523, '#523 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:49:10'),
(423, 518, '#518 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:49:13'),
(424, 421, '#421 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:49:21'),
(425, 435, '#435 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:49:28'),
(426, 444, '#444 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:49:32'),
(427, 465, '#465 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:49:43'),
(428, 476, '#476 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:49:48'),
(429, 498, '#498 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:49:59'),
(430, 503, '#503 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-16 20:50:01'),
(431, 519, '#519 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:50:06'),
(432, 511, '#511 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:50:06'),
(433, 436, '#436 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-16 20:50:06'),
(1465, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-21 17:10:15'),
(1466, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-21 17:11:11'),
(1467, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-21 18:11:12'),
(1468, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-21 18:12:11'),
(1469, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-21 23:15:14'),
(1470, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-21 23:16:13'),
(1471, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-22 07:04:12'),
(1472, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-22 07:05:15'),
(1473, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-22 09:28:13'),
(1474, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-22 09:29:10'),
(1475, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-22 09:51:12'),
(1476, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-22 09:52:13'),
(1477, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-22 12:33:18'),
(1478, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-22 12:34:08'),
(1479, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-22 14:00:13'),
(1480, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-22 14:01:11'),
(1481, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-22 17:52:14'),
(1482, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-22 17:53:13'),
(1483, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-23 13:55:18'),
(1484, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-23 13:56:07'),
(1485, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-24 02:14:13'),
(1486, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-24 02:15:08'),
(1458, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-20 21:48:13'),
(1487, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-24 18:18:12'),
(1488, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-24 18:19:12'),
(1489, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-24 21:15:20'),
(1490, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-24 21:16:10'),
(1491, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-25 08:15:15'),
(1492, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-25 08:16:09'),
(1493, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-25 16:55:14'),
(1494, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-25 16:56:14'),
(1495, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-26 15:09:14'),
(1496, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-26 15:10:06'),
(1497, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-26 20:05:17'),
(1498, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-26 20:05:17'),
(1499, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-26 20:06:12'),
(1500, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-26 20:06:14'),
(1501, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1502, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1503, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1504, 532, '#532 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1505, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1506, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1507, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1508, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1509, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1510, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1511, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1512, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:18:14'),
(1513, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:11'),
(1514, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:12'),
(1515, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:12'),
(1516, 532, '#532 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:13'),
(1517, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:13'),
(1518, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:14'),
(1519, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:15'),
(1520, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:15'),
(1521, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:16'),
(1522, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:16'),
(1523, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:17'),
(1524, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:20:17'),
(1525, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1526, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1527, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1528, 532, '#532 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1529, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1530, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1531, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1532, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1533, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1534, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1535, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1536, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:39:21'),
(1537, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:10'),
(1538, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:11'),
(1539, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:12');
INSERT INTO `serviceapi_alert` (`id`, `service_id`, `serviceapi_alert`, `servicealert_extra`, `servicealert_date`) VALUES
(1540, 532, '#532 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:13'),
(1541, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:13'),
(1542, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:14'),
(1543, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:14'),
(1544, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:15'),
(1545, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:15'),
(1546, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:16'),
(1547, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:16'),
(1548, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:41:17'),
(1549, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:43:16'),
(1550, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:43:16'),
(1551, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:43:16'),
(1552, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:43:16'),
(1553, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:44:13'),
(1554, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:44:13'),
(1555, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:44:13'),
(1556, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:44:14'),
(1557, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1558, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1559, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1560, 532, '#532 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1561, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1562, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1563, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1564, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1565, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1566, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1567, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1568, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:51:25'),
(1569, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:08'),
(1570, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:09'),
(1571, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:10'),
(1572, 532, '#532 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:10'),
(1573, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:10'),
(1574, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:11'),
(1575, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:12'),
(1576, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:12'),
(1577, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:13'),
(1578, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:13'),
(1579, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:14'),
(1580, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:52:14'),
(1581, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:53:15'),
(1582, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:53:15'),
(1583, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:53:15'),
(1584, 532, '#532 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:53:15'),
(1585, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:53:15'),
(1586, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:53:15'),
(1587, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:53:15'),
(1588, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:53:15'),
(1589, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:53:15'),
(1590, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 01:53:15'),
(1591, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:54:07'),
(1592, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:54:08'),
(1593, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:54:08'),
(1594, 532, '#532 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:54:09'),
(1595, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:54:09'),
(1596, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:54:10'),
(1597, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:54:10'),
(1598, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:54:11'),
(1599, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:54:12'),
(1600, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 01:54:12'),
(1601, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1602, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1603, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1604, 532, '#532 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1605, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1606, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1607, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1608, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1609, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1610, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1611, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1612, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:06:13'),
(1613, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:09'),
(1614, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:09'),
(1615, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:10'),
(1616, 532, '#532 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:10'),
(1617, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:11'),
(1618, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:11'),
(1619, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:12'),
(1620, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:12'),
(1621, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:13'),
(1622, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:13'),
(1623, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:13'),
(1624, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:07:14'),
(1625, 532, '#532 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:09:12'),
(1626, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:09:12'),
(1627, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:09:12'),
(1628, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:09:12'),
(1629, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:09:12'),
(1630, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:09:12'),
(1631, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:09:12'),
(1632, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:09:12'),
(1633, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:09:12'),
(1634, 532, '#532 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:10:03'),
(1635, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:10:04'),
(1636, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:10:04'),
(1637, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:10:05'),
(1638, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:10:05'),
(1639, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:10:05'),
(1640, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:10:06'),
(1641, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:10:07'),
(1642, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:10:07'),
(1643, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1644, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1645, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1646, 532, '#532 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1647, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1648, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1649, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1650, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1651, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1652, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1653, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1654, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 02:54:14'),
(1655, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:08'),
(1656, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:08'),
(1657, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:09'),
(1658, 532, '#532 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:10'),
(1659, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:10'),
(1660, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:11'),
(1661, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:11'),
(1662, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:12'),
(1663, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:12'),
(1664, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:13'),
(1665, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:13'),
(1666, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 02:56:14'),
(1667, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 03:04:13'),
(1668, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 03:04:13'),
(1669, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 03:04:13'),
(1670, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 03:04:13'),
(1671, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 03:04:13'),
(1672, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 03:04:13'),
(1673, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 03:04:13'),
(1674, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 03:04:13'),
(1675, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 03:05:12'),
(1676, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 03:05:12'),
(1677, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 03:05:13'),
(1678, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 03:05:13'),
(1679, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 03:05:14'),
(1680, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 03:05:14'),
(1681, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 03:05:14'),
(1682, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 03:05:15'),
(1683, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 13:15:17'),
(1684, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 13:16:16'),
(1685, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:15:16'),
(1686, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:16:13'),
(1687, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:46:20'),
(1688, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:46:20'),
(1689, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:46:20'),
(1690, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:47:13'),
(1691, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:47:14'),
(1692, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:47:14'),
(1693, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:54:19'),
(1694, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:54:19'),
(1695, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:54:19'),
(1696, 532, '#532 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:54:19'),
(1697, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:54:19'),
(1698, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:54:19'),
(1699, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:54:19'),
(1700, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:54:19'),
(1701, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 14:54:19'),
(1702, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:55:11'),
(1703, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:55:14'),
(1704, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:55:15'),
(1705, 532, '#532 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:55:16'),
(1706, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:55:16'),
(1707, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:55:17'),
(1708, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:55:17'),
(1709, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:55:17'),
(1710, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 14:55:18'),
(1711, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1712, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1713, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1714, 532, '#532 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1715, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1716, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1717, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1718, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1719, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1720, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1721, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1722, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 15:05:17'),
(1723, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:09'),
(1724, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:09'),
(1725, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:10'),
(1726, 532, '#532 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:11'),
(1727, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:12'),
(1728, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:13'),
(1729, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:13'),
(1730, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:14'),
(1731, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:14'),
(1732, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:15'),
(1733, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:15'),
(1734, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 15:06:16'),
(1735, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1736, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1737, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1738, 532, '#532 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1739, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1740, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1741, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1742, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1743, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1744, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1745, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1746, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-27 22:00:16'),
(1747, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:09'),
(1748, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:10'),
(1749, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:10'),
(1750, 532, '#532 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:12'),
(1751, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:13'),
(1752, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:14'),
(1753, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:15'),
(1754, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:15'),
(1755, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:16'),
(1756, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:17'),
(1757, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:18'),
(1758, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-27 22:01:18'),
(1759, 531, '#531 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-28 11:18:18'),
(1760, 531, '#531 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-28 11:19:08'),
(1761, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-28 21:34:16'),
(1762, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-28 21:35:16'),
(1763, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-29 01:53:14'),
(1764, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-29 01:54:10'),
(1765, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 00:20:17'),
(1766, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 00:21:15'),
(1767, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 08:34:15'),
(1768, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 08:35:15'),
(1769, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 10:48:15'),
(1770, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 10:49:14'),
(1771, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 12:05:16'),
(1772, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 12:06:15'),
(1773, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 16:32:23'),
(1774, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 16:32:23'),
(1775, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 16:32:23'),
(1776, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 16:32:23'),
(1777, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 16:33:09'),
(1778, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 16:33:10'),
(1779, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 16:33:10'),
(1780, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 16:33:12'),
(1781, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:02:15'),
(1782, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:02:15'),
(1783, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:02:15'),
(1784, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:02:15'),
(1785, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:02:15'),
(1786, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:02:15'),
(1787, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:02:15'),
(1788, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:02:15'),
(1789, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:02:15'),
(1790, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:02:15');
INSERT INTO `serviceapi_alert` (`id`, `service_id`, `serviceapi_alert`, `servicealert_extra`, `servicealert_date`) VALUES
(1791, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:03:08'),
(1792, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:03:09'),
(1793, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:03:09'),
(1794, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:03:11'),
(1795, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:03:12'),
(1796, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:03:12'),
(1797, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:03:13'),
(1798, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:03:15'),
(1799, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:03:15'),
(1800, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:03:18'),
(1801, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:16:20'),
(1802, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:16:20'),
(1803, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:16:20'),
(1804, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:16:20'),
(1805, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:16:20'),
(1806, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:16:20'),
(1807, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:16:20'),
(1808, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:16:20'),
(1809, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:16:20'),
(1810, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:16:20'),
(1811, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:19:19'),
(1812, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:20:11'),
(1813, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:20:13'),
(1814, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:20:14'),
(1815, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:20:14'),
(1816, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:20:16'),
(1817, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:20:16'),
(1818, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:20:17'),
(1819, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:20:18'),
(1820, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:20:19'),
(1821, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:22:19'),
(1822, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:22:19'),
(1823, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:23:09'),
(1824, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:23:09'),
(1825, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:32:22'),
(1826, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:32:22'),
(1827, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:32:22'),
(1828, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:32:22'),
(1829, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:32:22'),
(1830, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:33:08'),
(1831, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:33:09'),
(1832, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:33:09'),
(1833, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:33:09'),
(1834, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:33:10'),
(1835, 541, '#541 numaralı servis fiyatı değiştirilmiş.', '{\"old\":38.5,\"new\":34.10000000000000142108547152020037174224853515625}', '2021-08-30 17:39:15'),
(1836, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:53:15'),
(1837, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:53:15'),
(1838, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:53:15'),
(1839, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:53:15'),
(1840, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:53:15'),
(1841, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:53:15'),
(1842, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:53:15'),
(1843, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:53:15'),
(1844, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:53:15'),
(1845, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 17:53:15'),
(1846, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:54:08'),
(1847, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:54:09'),
(1848, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:54:09'),
(1849, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:54:10'),
(1850, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:54:10'),
(1851, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:54:11'),
(1852, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:54:11'),
(1853, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:54:11'),
(1854, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:54:12'),
(1855, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 17:54:15'),
(1856, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 18:43:21'),
(1857, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 18:43:21'),
(1858, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 18:43:21'),
(1859, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 18:43:21'),
(1860, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 18:43:21'),
(1861, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 18:43:21'),
(1862, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 18:43:21'),
(1863, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 18:43:21'),
(1864, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 18:43:21'),
(1865, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 18:43:21'),
(1866, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 18:46:10'),
(1867, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 18:46:11'),
(1868, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 18:46:13'),
(1869, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 18:46:14'),
(1870, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 18:46:15'),
(1871, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 18:46:15'),
(1872, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 18:46:16'),
(1873, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 18:46:17'),
(1874, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 18:46:18'),
(1875, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 18:46:22'),
(1876, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:12:14'),
(1877, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:12:14'),
(1878, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:12:14'),
(1879, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:12:14'),
(1880, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:12:14'),
(1881, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:12:14'),
(1882, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:12:14'),
(1883, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:12:14'),
(1884, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:12:14'),
(1885, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:12:14'),
(1886, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:19:07'),
(1887, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:19:07'),
(1888, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:19:08'),
(1889, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:19:08'),
(1890, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:19:09'),
(1891, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:19:10'),
(1892, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:19:10'),
(1893, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:19:11'),
(1894, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:19:11'),
(1895, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:19:14'),
(1896, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:23:16'),
(1897, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:23:16'),
(1898, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:23:16'),
(1899, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:23:16'),
(1900, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:23:16'),
(1901, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:23:16'),
(1902, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:23:16'),
(1903, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:23:16'),
(1904, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:23:16'),
(1905, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:23:16'),
(1906, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:25:10'),
(1907, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:25:11'),
(1908, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:25:11'),
(1909, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:25:12'),
(1910, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:25:13'),
(1911, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:25:13'),
(1912, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:25:14'),
(1913, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:25:14'),
(1914, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:25:15'),
(1915, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:25:18'),
(1916, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:32:16'),
(1917, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:33:28'),
(1918, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:44:15'),
(1919, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:45:17'),
(1920, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:52:14'),
(1921, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:52:14'),
(1922, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:52:14'),
(1923, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:52:14'),
(1924, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:52:14'),
(1925, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:52:14'),
(1926, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:52:14'),
(1927, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:52:14'),
(1928, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 20:52:14'),
(1929, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:53:09'),
(1930, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:53:09'),
(1931, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:53:10'),
(1932, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:53:10'),
(1933, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:53:11'),
(1934, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:53:11'),
(1935, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:53:11'),
(1936, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:53:12'),
(1937, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 20:53:15'),
(1938, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:00:21'),
(1939, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:00:21'),
(1940, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:00:21'),
(1941, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:00:21'),
(1942, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:00:21'),
(1943, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:00:21'),
(1944, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:00:21'),
(1945, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:01:08'),
(1946, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:01:08'),
(1947, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:01:09'),
(1948, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:01:09'),
(1949, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:01:10'),
(1950, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:01:11'),
(1951, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:01:11'),
(1952, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:14:16'),
(1953, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:14:16'),
(1954, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:14:16'),
(1955, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:14:16'),
(1956, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:14:16'),
(1957, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:14:16'),
(1958, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 21:14:16'),
(1959, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:15:11'),
(1960, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:15:12'),
(1961, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:15:13'),
(1962, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:15:13'),
(1963, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:15:14'),
(1964, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:15:14'),
(1965, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 21:15:18'),
(1966, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:18:15'),
(1967, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:18:15'),
(1968, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:18:15'),
(1969, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:18:15'),
(1970, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:18:15'),
(1971, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:18:15'),
(1972, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:18:15'),
(1973, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:18:15'),
(1974, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:18:15'),
(1975, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:18:15'),
(1976, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:19:08'),
(1977, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:19:08'),
(1978, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:19:09'),
(1979, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:19:09'),
(1980, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:19:10'),
(1981, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:19:10'),
(1982, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:19:11'),
(1983, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:19:12'),
(1984, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:19:12'),
(1985, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:19:15'),
(1986, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:20:16'),
(1987, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:20:16'),
(1988, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:20:16'),
(1989, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:20:16'),
(1990, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:20:16'),
(1991, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:20:16'),
(1992, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:20:16'),
(1993, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:20:16'),
(1994, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:20:16'),
(1995, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-30 22:20:16'),
(1996, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:21:16'),
(1997, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:22:08'),
(1998, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:22:08'),
(1999, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:22:09'),
(2000, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:22:10'),
(2001, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:22:10'),
(2002, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:22:11'),
(2003, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:22:11'),
(2004, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:22:12'),
(2005, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-30 22:22:12'),
(2006, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 01:33:24'),
(2007, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 01:34:08'),
(2008, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:06:15'),
(2009, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:06:15'),
(2010, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:07:13'),
(2011, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:07:16'),
(2012, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:15:15'),
(2013, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:15:15'),
(2014, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:15:15'),
(2015, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:15:15'),
(2016, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:15:15'),
(2017, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:15:15'),
(2018, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:15:15'),
(2019, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:15:15'),
(2020, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:15:15'),
(2021, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:15:15'),
(2022, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:16:10'),
(2023, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:16:11'),
(2024, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:16:11'),
(2025, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:16:11'),
(2026, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:16:12'),
(2027, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:16:12'),
(2028, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:16:13'),
(2029, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:16:13'),
(2030, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:16:14'),
(2031, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:16:17'),
(2032, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:54:15'),
(2033, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:54:15'),
(2034, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:54:15'),
(2035, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:54:15'),
(2036, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:54:15'),
(2037, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:54:15'),
(2038, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:54:15'),
(2039, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:54:15'),
(2040, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:54:15'),
(2041, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:55:11'),
(2042, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:55:12');
INSERT INTO `serviceapi_alert` (`id`, `service_id`, `serviceapi_alert`, `servicealert_extra`, `servicealert_date`) VALUES
(2043, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:55:12'),
(2044, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:55:12'),
(2045, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:55:13'),
(2046, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:55:13'),
(2047, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:55:14'),
(2048, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:55:14'),
(2049, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:55:17'),
(2050, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:58:16'),
(2051, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:58:16'),
(2052, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:58:16'),
(2053, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 15:58:16'),
(2054, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:59:07'),
(2055, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:59:08'),
(2056, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:59:09'),
(2057, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 15:59:09'),
(2058, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:20:17'),
(2059, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:21:15'),
(2060, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:46:54'),
(2061, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:46:54'),
(2062, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:46:54'),
(2063, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:46:54'),
(2064, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:46:54'),
(2065, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:46:54'),
(2066, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:46:54'),
(2067, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:46:54'),
(2068, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:46:54'),
(2069, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 17:46:54'),
(2070, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:48:14'),
(2071, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:48:17'),
(2072, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:48:17'),
(2073, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:48:20'),
(2074, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:48:20'),
(2075, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:48:21'),
(2076, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:48:22'),
(2077, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:48:27'),
(2078, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:49:09'),
(2079, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 17:49:10'),
(2080, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:21:16'),
(2081, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:21:16'),
(2082, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:21:16'),
(2083, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:21:16'),
(2084, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:21:16'),
(2085, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:21:16'),
(2086, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:21:16'),
(2087, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:21:16'),
(2088, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:21:16'),
(2089, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:21:16'),
(2090, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:22:08'),
(2091, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:22:09'),
(2092, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:22:09'),
(2093, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:22:10'),
(2094, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:22:10'),
(2095, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:22:11'),
(2096, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:22:12'),
(2097, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:22:12'),
(2098, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:22:12'),
(2099, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:22:15'),
(2100, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 18:45:16'),
(2101, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 18:46:12'),
(2102, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:14:16'),
(2103, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:14:16'),
(2104, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:14:16'),
(2105, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:14:16'),
(2106, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:14:16'),
(2107, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:15:10'),
(2108, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:15:10'),
(2109, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:15:11'),
(2110, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:15:11'),
(2111, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:15:11'),
(2112, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:23:16'),
(2113, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:23:16'),
(2114, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:23:16'),
(2115, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:23:16'),
(2116, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:24:08'),
(2117, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:24:09'),
(2118, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:24:10'),
(2119, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:24:10'),
(2120, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:36:19'),
(2121, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 20:36:19'),
(2122, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:37:06'),
(2123, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 20:37:07'),
(2124, 529, '#529 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 21:47:16'),
(2125, 530, '#530 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 21:47:16'),
(2126, 533, '#533 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 21:47:16'),
(2127, 534, '#534 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 21:47:16'),
(2128, 535, '#535 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 21:47:16'),
(2129, 536, '#536 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 21:47:16'),
(2130, 537, '#537 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 21:47:16'),
(2131, 538, '#538 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 21:47:16'),
(2132, 539, '#539 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 21:47:16'),
(2133, 541, '#541 numaralı servis sağlayıcı tarafından kaldırılmış.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\"}', '2021-08-31 21:47:16'),
(2134, 529, '#529 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 21:48:09'),
(2135, 530, '#530 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 21:48:11'),
(2136, 533, '#533 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 21:48:13'),
(2137, 534, '#534 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 21:48:14'),
(2138, 535, '#535 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 21:48:15'),
(2139, 536, '#536 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 21:48:16'),
(2140, 537, '#537 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 21:48:16'),
(2141, 538, '#538 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 21:48:17'),
(2142, 539, '#539 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 21:48:17'),
(2143, 541, '#541 numaralı servis sağlayıcı tarafından yeniden aktif edilmiş.', '{\"old\":\"Sa\\u011flay\\u0131c\\u0131da Pasif\",\"new\":\"Sa\\u011flay\\u0131c\\u0131da Aktif\"}', '2021-08-31 21:48:20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_api` int(11) NOT NULL DEFAULT 0,
  `api_service` int(11) NOT NULL DEFAULT 0,
  `api_servicetype` enum('1','2') NOT NULL DEFAULT '2',
  `api_detail` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `service_line` double NOT NULL,
  `service_type` enum('1','2') NOT NULL DEFAULT '2',
  `service_package` enum('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17') NOT NULL,
  `service_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `service_description` text DEFAULT NULL,
  `service_price` double NOT NULL DEFAULT 0,
  `service_min` double NOT NULL,
  `service_max` double NOT NULL,
  `service_dripfeed` enum('1','2') NOT NULL DEFAULT '1',
  `service_autotime` double NOT NULL DEFAULT 0,
  `service_autopost` double NOT NULL DEFAULT 0,
  `service_speed` enum('1','2','3','4') NOT NULL,
  `want_username` enum('1','2') NOT NULL DEFAULT '1',
  `service_secret` enum('1','2') NOT NULL DEFAULT '2',
  `price_type` enum('normal','percent','amount') NOT NULL DEFAULT 'normal',
  `price_cal` text DEFAULT NULL,
  `instagram_second` enum('1','2') NOT NULL DEFAULT '2',
  `start_count` enum('none','instagram_follower','instagram_photo','') NOT NULL,
  `instagram_private` enum('1','2') NOT NULL,
  `name_lang` text DEFAULT NULL,
  `description_lang` text DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `service_api`
--

CREATE TABLE `service_api` (
  `id` int(11) NOT NULL,
  `api_name` varchar(225) NOT NULL,
  `api_url` text NOT NULL,
  `api_key` varchar(225) NOT NULL,
  `api_type` int(11) NOT NULL,
  `api_limit` double NOT NULL DEFAULT 0,
  `currency` enum('INR','USD') DEFAULT NULL,
  `api_alert` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> Gönder, 1 -> Gönderildi'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_seo` text NOT NULL,
  `site_title` text DEFAULT NULL,
  `site_description` text DEFAULT NULL,
  `site_keywords` text DEFAULT NULL,
  `site_logo` text DEFAULT NULL,
  `site_name` text DEFAULT NULL,
  `site_currency` varchar(2555) NOT NULL DEFAULT 'try',
  `favicon` text DEFAULT NULL,
  `site_language` varchar(225) NOT NULL DEFAULT 'tr',
  `site_theme` text NOT NULL,
  `site_theme_alt` text DEFAULT NULL,
  `recaptcha` enum('1','2') NOT NULL DEFAULT '1',
  `recaptcha_key` text DEFAULT NULL,
  `recaptcha_secret` text DEFAULT NULL,
  `custom_header` text DEFAULT NULL,
  `custom_footer` text DEFAULT NULL,
  `ticket_system` enum('1','2') NOT NULL DEFAULT '2',
  `register_page` enum('1','2') NOT NULL DEFAULT '2',
  `service_speed` enum('1','2') NOT NULL,
  `service_list` enum('1','2') NOT NULL,
  `dolar_charge` double NOT NULL,
  `euro_charge` double NOT NULL,
  `smtp_user` text NOT NULL,
  `smtp_pass` text NOT NULL,
  `smtp_server` text NOT NULL,
  `smtp_port` varchar(225) NOT NULL,
  `smtp_protocol` enum('0','ssl','tls') NOT NULL,
  `alert_type` enum('1','2','3') NOT NULL,
  `alert_newbankpayment` enum('1','2') NOT NULL,
  `alert_newmanuelservice` enum('1','2') NOT NULL,
  `alert_newticket` enum('1','2') NOT NULL,
  `alert_apibalance` enum('1','2') NOT NULL,
  `alert_serviceapialert` enum('1','2') NOT NULL,
  `sms_provider` varchar(225) NOT NULL,
  `sms_title` varchar(225) NOT NULL,
  `sms_user` varchar(225) NOT NULL,
  `sms_pass` varchar(225) NOT NULL,
  `sms_validate` enum('0','1') NOT NULL DEFAULT '0' COMMENT '1 -> OK, 0 -> NO',
  `admin_mail` varchar(225) NOT NULL,
  `admin_telephone` varchar(225) NOT NULL,
  `resetpass_page` enum('1','2') NOT NULL,
  `resetpass_sms` enum('1','2') NOT NULL,
  `resetpass_email` enum('1','2') NOT NULL,
  `site_maintenance` enum('1','2') NOT NULL DEFAULT '2',
  `servis_siralama` varchar(255) NOT NULL,
  `bronz_statu` int(11) NOT NULL,
  `silver_statu` int(11) NOT NULL,
  `gold_statu` int(11) NOT NULL,
  `bayi_statu` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `settings`
--

INSERT INTO `settings` (`id`, `site_seo`, `site_title`, `site_description`, `site_keywords`, `site_logo`, `site_name`, `site_currency`, `favicon`, `site_language`, `site_theme`, `site_theme_alt`, `recaptcha`, `recaptcha_key`, `recaptcha_secret`, `custom_header`, `custom_footer`, `ticket_system`, `register_page`, `service_speed`, `service_list`, `dolar_charge`, `euro_charge`, `smtp_user`, `smtp_pass`, `smtp_server`, `smtp_port`, `smtp_protocol`, `alert_type`, `alert_newbankpayment`, `alert_newmanuelservice`, `alert_newticket`, `alert_apibalance`, `alert_serviceapialert`, `sms_provider`, `sms_title`, `sms_user`, `sms_pass`, `sms_validate`, `admin_mail`, `admin_telephone`, `resetpass_page`, `resetpass_sms`, `resetpass_email`, `site_maintenance`, `servis_siralama`, `bronz_statu`, `silver_statu`, `gold_statu`, `bayi_statu`) VALUES
(1, 'zeyinsta', 'zeyinsta', 'compre seguidores seguidores baratos', 'zeyinsta', '', 'teste canal', 'USD', '', 'en', 'pro', 'Lightblue', '1', '', '', '', '', '2', '2', '2', '2', 76, 76, 'suportezeyinsta@gmail.com', 'Lindo1996', '', '465', 'ssl', '1', '2', '2', '2', '2', '2', 'bizimsms', 'zeyinsta', 'zeyinsta', 'Lindo1996', '1', 'suportezeyinsta@gmail.com', '82981292504', '2', '1', '2', '2', 'desc', 2147483647, 2147483647, 2147483647, 52);

-- --------------------------------------------------------

--
-- Estrutura da tabela `themes`
--

CREATE TABLE `themes` (
  `id` int(11) NOT NULL,
  `theme_name` text NOT NULL,
  `theme_dirname` text NOT NULL,
  `theme_extras` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `themes`
--

INSERT INTO `themes` (`id`, `theme_name`, `theme_dirname`, `theme_extras`) VALUES
(12, 'pro', 'pro', '{\"stylesheets\":[\"public/pro/panel/1607327652/bootstrap.css\",\"public/pro/pro/panel/style.css\",\"https:\\/\\/stackpath.bootstrapcdn.com\\/font-awesome\\/4.7.0\\/css\\/font-awesome.min.css\",\"public\\/datepicker\\/css\\/bootstrap-datepicker3.min.css\"],\"scripts\":[\"https:\\/\\/code.jquery.com\\/jquery-3.3.1.min.js\",\"public/pro/script.js\",\"public/ajax.js\",\"public/pro/bootstrap.js\",\"public\\/datepicker\\/js\\/bootstrap-datepicker.min.js\",\"public\\/datepicker\\/locales\\/bootstrap-datepicker.en.min.js\"]}');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `time` datetime NOT NULL,
  `lastupdate_time` datetime NOT NULL,
  `client_new` enum('1','2') NOT NULL DEFAULT '2',
  `status` enum('pending','answered','closed') NOT NULL DEFAULT 'pending',
  `support_new` enum('1','2') NOT NULL DEFAULT '1',
  `canmessage` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tickets`
--

INSERT INTO `tickets` (`ticket_id`, `client_id`, `subject`, `time`, `lastupdate_time`, `client_new`, `status`, `support_new`, `canmessage`) VALUES
(6, 174, 'Comprei 10 contas', '2021-08-22 21:48:05', '2021-08-22 21:56:17', '1', 'answered', '1', '2'),
(7, 174, 'Essa conta não está funcionando', '2021-08-22 22:52:56', '2021-08-22 22:52:56', '1', 'pending', '1', '2'),
(8, 174, 'Seguidores', '2021-08-23 01:33:48', '2021-08-23 01:33:48', '1', 'closed', '1', '2'),
(9, 200, 'Noel21kk', '2021-08-30 03:37:06', '2021-08-31 16:35:23', '2', 'pending', '1', '2'),
(10, 200, 'Noel21kk', '2021-08-30 03:58:06', '2021-08-30 05:29:05', '1', 'answered', '1', '2'),
(11, 200, 'Noel21kk', '2021-08-31 16:41:59', '2021-08-31 16:41:59', '2', 'pending', '1', '2'),
(12, 174, 'Compra de emails', '2021-09-01 02:04:43', '2021-09-01 02:09:05', '2', 'pending', '1', '2');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ticket_reply`
--

CREATE TABLE `ticket_reply` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `time` datetime NOT NULL DEFAULT current_timestamp(),
  `support` enum('1','2') NOT NULL DEFAULT '1',
  `message` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `ticket_reply`
--

INSERT INTO `ticket_reply` (`id`, `ticket_id`, `client_id`, `time`, `support`, `message`) VALUES
(10, 6, 0, '2021-08-22 21:48:05', '1', 'Boa tarde, eu comprei 10 contas vazias no Instagram para enviar no e-mail pequenakati@hotmail.com que escrevi no username .\r\nMinha conta é reicomerce\r\n'),
(11, 6, 0, '2021-08-22 21:50:33', '2', 'ok já irei verificar seu pedido\r\n\r\n\r\nequipe zeyinsta...'),
(12, 6, 0, '2021-08-22 21:52:36', '2', 'pedido confirmado suas contas esta aqui ....\r\n\r\nmartina_jhsouza\r\n40028922\r\n\r\nfrancisco_qhsouza\r\n40028922\r\n\r\nfelipe_qrresende\r\n40028922\r\n\r\nclarice_amdrumond\r\n40028922\r\n\r\nlucca_apsalazar\r\n40028922\r\n\r\nadele_pbximenes\r\n40028922\r\n\r\ngabrielle_nrgoulart\r\n40028922\r\n\r\nbetina_bgjaques\r\n40028922\r\n\r\nandre_ljjaques\r\n40028922\r\n\r\naugusta_efmaldonado\r\n40028922'),
(13, 6, 0, '2021-08-22 21:56:17', '2', 'a senha de todos são esses numeros ai \r\n'),
(14, 7, 0, '2021-08-22 22:52:56', '1', 'Boa tarde, agora pouco comprei 10 contas e essa conta em específico não está funcionando\r\nfancisco_qhsouza'),
(15, 8, 0, '2021-08-23 01:33:48', '1', 'Ola, eu tinha comprado seguidores para 10 contas e 4 ainda estão pendentes são essas, sera que pode agilizar para mim?\r\n	francisco_qhsouza\r\n	augusta_efmaldonado\r\n        andre_ljjaques\r\n         betina_bgjaques\r\n'),
(16, 9, 0, '2021-08-30 03:37:06', '1', 'Oi queria saber se tem estoque de contas disponíveis'),
(17, 10, 0, '2021-08-30 03:58:06', '1', 'Pedido id 43'),
(18, 9, 0, '2021-08-30 03:58:09', '2', 'olá \r\nsim quantas vc quer ?'),
(19, 9, 0, '2021-08-30 04:02:00', '1', 'Ola quero 10 na verdade já fiz a compra'),
(20, 9, 0, '2021-08-30 04:07:03', '2', 'ok só aguarda aqui .;....'),
(21, 10, 0, '2021-08-30 05:29:05', '2', 'em até 24hrs suas contas vai está  qui ...'),
(22, 9, 0, '2021-08-31 01:02:27', '1', 'Ola.....'),
(23, 9, 0, '2021-08-31 01:54:34', '2', 'olá aqui estão suas contas \r\n1-  delltainsta1\r\n2-  delltainsta2\r\n3-  delltainsta3\r\n4-  delltainsta4\r\n5-  delltainsta5\r\n6-  delltainsta6\r\n\r\nsenha de todas as contas ?  ne0011\r\n\r\nmuito obrigado por nos contratar equipe zeyyinnssta....'),
(24, 9, 0, '2021-08-31 02:04:49', '1', 'Ola no caso o pedido eram 10 contas por 6 reais , e só recebi 6 contas'),
(25, 9, 0, '2021-08-31 16:34:07', '1', 'Olaaa??????'),
(26, 9, 0, '2021-08-31 16:35:23', '1', 'Cada conta era 0.6 paguei R$ 6 quero minhas outras 4'),
(27, 11, 0, '2021-08-31 16:41:59', '1', 'Ola bom dia....'),
(28, 12, 0, '2021-09-01 02:04:43', '1', 'Comprei 20 emails\r\nE o email que coloquei foi\r\npequenakati@hotmail.com'),
(29, 12, 0, '2021-09-01 02:09:05', '1', 'Na verdade  não é email é contas do Instagram kkk');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Índices para tabela `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`);

--
-- Índices para tabela `clients_category`
--
ALTER TABLE `clients_category`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `clients_price`
--
ALTER TABLE `clients_price`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `clients_service`
--
ALTER TABLE `clients_service`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `client_report`
--
ALTER TABLE `client_report`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `kuponlar`
--
ALTER TABLE `kuponlar`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `kupon_kullananlar`
--
ALTER TABLE `kupon_kullananlar`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Índices para tabela `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`page_id`);

--
-- Índices para tabela `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Índices para tabela `payments_bonus`
--
ALTER TABLE `payments_bonus`
  ADD PRIMARY KEY (`bonus_id`);

--
-- Índices para tabela `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `serviceapi_alert`
--
ALTER TABLE `serviceapi_alert`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Índices para tabela `service_api`
--
ALTER TABLE `service_api`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`);

--
-- Índices para tabela `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Índices para tabela `ticket_reply`
--
ALTER TABLE `ticket_reply`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT de tabela `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=218;

--
-- AUTO_INCREMENT de tabela `clients_category`
--
ALTER TABLE `clients_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `clients_price`
--
ALTER TABLE `clients_price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `clients_service`
--
ALTER TABLE `clients_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `client_report`
--
ALTER TABLE `client_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=387;

--
-- AUTO_INCREMENT de tabela `kuponlar`
--
ALTER TABLE `kuponlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `kupon_kullananlar`
--
ALTER TABLE `kupon_kullananlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT de tabela `pages`
--
ALTER TABLE `pages`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT de tabela `payments_bonus`
--
ALTER TABLE `payments_bonus`
  MODIFY `bonus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `serviceapi_alert`
--
ALTER TABLE `serviceapi_alert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2144;

--
-- AUTO_INCREMENT de tabela `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=550;

--
-- AUTO_INCREMENT de tabela `service_api`
--
ALTER TABLE `service_api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `themes`
--
ALTER TABLE `themes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de tabela `ticket_reply`
--
ALTER TABLE `ticket_reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
